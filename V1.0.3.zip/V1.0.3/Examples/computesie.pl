#/usr/bin/perl
$bin = 5;
$D = 15;
$st = 1000;
$en = 199000;
@dirs = ('PasProx','ActDist','PasDist', 'ActProx'); 

$i =0;
foreach $d (@dirs) { 
    system "cd $d; java SIEEstimator_tmp $D $st $en $bin 0 0 > sie_res_${D}_${bin}.txt";

    for ($i=2;$i<=30;$i=$i+4) { 
	print STDERR $d," ",$i;
    system "cd $d; java  SIEEstimator_tmp $D $st $en $bin 0 $i >> sie_res_${D}_${bin}.txt";

    }
}
#    system "awk \"((NR%3)==0) { print $1 }\" sie_res.tmp > sie_res.txt";

