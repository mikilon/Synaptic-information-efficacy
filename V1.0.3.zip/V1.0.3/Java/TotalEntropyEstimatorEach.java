import mpfun.*;
import java.io.*;
import java.util.*;
import java.lang.*;
/**
 * NoiseEntropyEstimator  allows to  estimate the entropy rate (in units of bits/symbol) 
 * of the noise when given many replicas of output spike train given the same stimulus. 
 * <br>
 * The class uses the CTW algorithm. For details of the CTW original algorithm see: <br>
 *  <a href="http://www.ics.ele.tue.nl/~fwillems/ResearchCTW.html">http://www.ics.ele.tue.nl/~fwillems/ResearchCTW.html</a>
 * <br>
 * For details of the adaptation of the algorithm to entropy estimation please look at either 
 * the file in this folder: <br>
 * Or look for it at:<br>
 *  <a href="http://www.dendrite.org/~mikilon/">http://www.dendrite.org/~mikilon/</a> <br>
 *  <a href="http://www.spike.ls.huji.ac.il/~mikilon/publications/">http://www.spike.ls.huji.ac.il/~mikilon/publications/</a>
 * <br>
 * @author Mickey London (m.london@ucl.co.uk, mikilon@lobster.ls.huji.ac.il) 
 */


public final class TotalEntropyEstimatorEach
{
    private static ArrayList allsources = new ArrayList();
    private static ArrayList allestimates = new ArrayList();
    
    public static void main(String args[]) throws java.io.IOException
    {    
	int nextsym = -1;
	SourceSequence source;
	int m,n;
	CTWEntropyEstimator estimator;

	readAllSources(args);
	m = allsources.size();
	source = (SourceSequence) allsources.get(0); 
	n = source.length();
	System.out.println(m + " " + n);


	for (int j = 0;j<m;j++) { 
	    estimator = new CTWEntropyEstimator((SourceSequence) allsources.get(j),CTWConst.D,CTWConst.D+1,n-1);   
	    allestimates.add(new Float(estimator.estimate().floatValue()));
	}
	saveEstimates(args[1],CTWConst.D,Float.parseFloat(args[4]));
    }

    private static void readAllSources(String args[]) throws java.io.IOException 
    { 
	CTWConst.D = Integer.parseInt(args[0]);
	float start = Float.parseFloat(args[2]);
	float duration = Float.parseFloat(args[3]);
	float binsize = Float.parseFloat(args[4]);


	try { 
	    FileListReader flr = new FileListReader(args[1]);
	    String fn;
	    while ( (fn = flr.readNextString() ) != null) { 
		System.out.println("Reading: "+fn);
		SourceSequence source = new SourceSequence(fn,start,duration,binsize);    
		allsources.add(source);
	    } 
	} catch (Exception e) {
	    e.printStackTrace();
	}
    }
    
    private static void saveEstimates(String  fname, int D, float bin) throws java.io.IOException { 
	Float val;
	File out = new File(fname+".TotalHE_"+D+"_" +bin);   //h est with dynamic ctw
	FileWriter fw = new FileWriter ( out ); 
	PrintWriter pw = new PrintWriter( fw, true ); 
	ListIterator li = allestimates.listIterator();
	while (li.hasNext() ) { 
	    val = (Float) li.next();
	    pw.println(val.floatValue()); 
	}
	fw.close();
    }
}






















