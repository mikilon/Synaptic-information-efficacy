public abstract class CTWConst{
    protected static int alphabet = 2;
    protected static int inalphabet = 2;
    protected static int D = 1000000;
    protected static boolean RH = false;
    protected static int method = 1; // 1 - ctw, 2 - ml   
    public static void setRH(){ 
	RH = true;
        inalphabet = 4;
    }	
}
