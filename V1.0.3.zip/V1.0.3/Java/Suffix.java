
// dummy implementaion using the StringBuffer class

public class Suffix extends Object {
    private String suffix;

    public Suffix(String s){
	suffix = s;
    }

    public Suffix sminus1() { 

       return new Suffix(suffix.substring(0,suffix.length()-1));		
    }

    public char pop() {   
	return suffix.charAt(suffix.length()-1);
    }

    public char popLeft() {   
	return suffix.charAt(0);
    }

    public void update(int nextsym) {  
        nextsym += (int) '0'; 
	char nextsymbol = (char) nextsym;

	// suffix = new String(nextsymbol+this.suffix.substring(0,suffix.length()-1));
	suffix = new String(this.suffix.substring(1,suffix.length())+nextsymbol);
	//System.out.println("Suffix update:"+suffix);
    }

    public void update(SourceSequence s,int n) {  
	suffix = s.getSuffixStr(n);
//        System.out.println(suffix.length()+" "+suffix);
    }

    public boolean isEmpty() { 
	if (suffix.length() == 0 ) { 
	   return true;
        } else { 
	   return false;
        }	
    }

    public int length() { 
	return suffix.length();
    }

    public String toString(){
	return suffix;
    }
}





