package timer;

public final class Timer
{

   long time = 0;
   public void start()
   {
      time = System.currentTimeMillis();
   }

   public void stop()
   {
      time = System.currentTimeMillis() - time;
   }

   public void reset()
   {
      time = 0;
   }

   public boolean isLessThanTwoSeconds()
   {
      double second = (double) time/1000.0;
      return second < 2.0; 
   }

   public void report(int numOfIteration)
   {
      double second = (double) time/1000.0;
      second /= numOfIteration;
      System.out.println(second + " seconds");
   }

   public void milliReport(int numOfIteration)
   {
      System.out.println(((double)time/numOfIteration) + " milliseconds");
   }
}
