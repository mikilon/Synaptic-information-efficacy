package mpfun;

/**  
 * This class represents the precision (in decimal digits) of mp objects.
 *
 * @author Herman Harjono
 * @version Oct 5, 1998.
 */ 
public final class MPPrecision 
{
  int size;
  public MPPrecision(int in)
    {size=in;}    
}

