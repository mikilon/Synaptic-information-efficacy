package mpfun;

/**  
 * This class represents the size of the mantissa array of mp objects.
 *
 * @author Herman Harjono
 * @version Oct 5, 1998.
 */ 
final class MPSize 
{
  int size;
  MPSize(int in)
    {size=in;}    
}

