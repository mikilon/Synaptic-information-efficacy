import mpfun.*;

/*
* Performs real-to-complex and complex-to-real FFT routines using routines
* RCFFTZ, CRFFTZ and CFFTZ.  These routines use double precision data, not
* complex.  Converted to Fortran-90 based multiprecision.
* David H. Bailey     May 4, 1994
*
* Translated to Java.
*
* Herman Harjono.
* 28 October 1994.
*/
public final class FftReal 
{
   static final MPReal POINTFIVE = new MPReal(0.5);
   static final MPReal ZERO = new MPReal();
   static final MPReal TWO = new MPReal(2);

  public static void main(String args[])
  {
    
    final int m = 10;
    final int n = 1024;
    final int it = 10;
    MPReal u[] = new MPReal[2*n], x[] = new MPReal[n+2], 
      y[] = new MPReal[n+2], se;
    double s[] = new double[n];
    
    // Initialize.  The SECOND function is assumed to be the timing function
    // on the given computer.  Change here and below if another name is used.
    
    MPReal rn = new MPReal(1.0/n);
    cfftz(0, m, u, x, y);
    MPReal realN = new MPReal(n);
    //Perform IT iterations.
    for (int ii = 1; ii <= it; ii++)
    {
      MPReal realS[] = new MPReal[n];
      int i;
      for (i = 0; i < n; i++) 
      {
        s[i] = MPReal.rand().doubleValue();
        realS[i] = new MPReal(s[i]);
        x[i] = realS[i];
      }
      
      rcfftz(-1, m, u, x, y);
      
      crfftz(1, m, u, x, y);
      se = ZERO;
      for (i = 0; i < n; i++)
        se = rn.multiply(x[i]).subtract(realS[i]).pow(2).add(se);

      se = se.divide(realN).sqrt();
      System.out.println("Iteration " + ii + "   Error = ");
      System.out.print(se);
      if (se.compareTo(MPReal.mpeps) > 0) 
      {
        System.out.println(MPReal.mpeps);
        throw new ArithmeticException("*** Error detected");
      }
    }
    
   System.out.println("Test passed.");
  }
  
  /*
  * Performs an N-point real-to-complex FFT, where N = 2^M.  X is both the
  * input and the output data array, and Y is a scratch array.  N real values
  * are input in X, and N/2 + 1 complex values are output in X, with real and
  * imaginary parts separated by N/2 + 1 locations.  Before calling RCFFTZ,
  * the U array must be initialized by calling CFFTZ with IS = 0.  A call to
  * RCFFTZ with IS = 1 (or -1) indicates a call to perform a real-to-complex
  * FFT with positive (or negative) exponentials.  The arrays X and Y must be
  * dimensioned with N/2 + 1 complex or N + 2 real cells.  U must be
  * dimensioned the same as in CFFTZ.  The output values from RCFFTZ are
  * twice as large as the results of a complex-to-complex transform on real
  * data.  M must be at least three.
  *
  * This subroutine employs a technique that converts a real-to-complex FFT
  * to a complex-to-complex FFT.  See Brigham, "The Fast Fourier Transform",
  * p. 169, and Hockney & Jesshope, "Parallel Computers", p. 303, although
  * neither reference is complete and error-free.
  * 
  * David H. Bailey     May 4, 1988
  */
  static void rcfftz(final int is, final int m, MPReal u[], MPReal x[],
    MPReal y[])   
  {
    // Set initial parameters.
    int n = (int) Math.pow(2, m);
    int mx = u[1-1].intValue();
    int nu = (int) Math.pow(2, mx);
    int n2 = n/2;
    int n21 = n2+1;
    int n4 = n/4;
    int ku = n/2;
    int kn = ku+nu;
    
    // Check if input parameters are invalid.
    if ((is != 1 && is != -1) || m < 3 || m > mx) 
    {
      throw new ArithmeticException(
        "RCFFTZ: Either U has not been initialized, or else " +
        "one of the input parameters is invalid " +
        is + " " + m + " " + mx);
    }
    
    // Copy X to Y such that Y(k) = X(2k-1) + i X(2k).
    // This loop is vectorizable.
    int k;  
    for (k = 1; k <= n2; k++) 
    {
      y[k-1] = x[2*k-1-1];
      y[k+n2-1] = x[2*k-1];
    }
    
    MPReal realIS = new MPReal(is);
    // Perform a normal N/2-point FFT on Y.
    cfftz(is, m-1, u, y, x);
    // Reconstruct the FFT of X.
    x[1-1] = y[1-1].add(y[n21-1]).multiply(TWO);
    x[n21+1-1] = ZERO;
    x[n4+1-1] = TWO.multiply(y[n4+1-1]);
    x[n4+1+n21-1] = TWO.multiply(realIS).multiply(y[n4+n2+1-1]);
    x[n21-1] = y[1-1].subtract(y[n21-1]).multiply(TWO);
    x[n+2-1] = ZERO;
    
    MPReal y11, y12, y21, y22, a1, a2, b1, b2, u1, u2, t1, t2;
    // This loop is vectorizable.
    for (k = 2; k <= n4; k++) 
    {
      y11 = y[k-1];
      y12 = y[k+n2-1];
      y21 = y[n2+2-k-1];
      y22 = y[n+2-k-1];
      a1 = y11.add(y21);
      a2 = y11.subtract(y21);
      b1 = y12.add(y22);
      b2 = y12.subtract(y22);
      u1 = u[k+ku-1];
      u2 = realIS.multiply(u[k+kn-1]);
      t1 = u1.multiply(b1).add(u2.multiply(a2));
      t2 = u1.negate().multiply(a2).add(u2.multiply(b1));
      x[k-1] = a1.add(t1);
      x[k+n21-1] = b2.add(t2);
      x[n2+2-k-1] = a1.subtract(t1);
      x[n+3-k-1] = b2.negate().add(t2);
    }
  }
  
  /*
  * Performs an N-point complex-to-real FFT, where N = 2^M.  X is both the
  * input and the output data array, and Y is a scratch array.  N/2 + 1
  * complex values are input in X, with real and imaginary parts separated by
  * N/2 + 1 locations, and N real values are output.  Before calling CRFFTZ,
  * the U array must be initialized by calling CFFTZ with IS = 0.  A call to
  * CRFFTZ with IS = 1 (or -1) indicates a call to perform a complex-to-real
  * FFT with positive (or negative) exponentials.  The arrays X and Y must be
  * dimensioned with N/2 + 1 complex or N + 2 real cells.  U must be
  * dimensioned the same as in CFFTZ.  M must be at least three.
  *
  * This subroutine employs a technique that converts a complex-to-real FFT
  * to a complex-to-complex FFT.  See Brigham, "The Fast Fourier Transform",
  * p. 169, and Hockney & Jesshope, "Parallel Computers", p. 303, although
  * neither reference is complete and error-free.
  *  
  * David H. Bailey     May 4, 1988
  */
  static void crfftz(final int is, final int m, MPReal u[], MPReal x[],
    MPReal y[])
  {
    // Set initial parameters.
    int n = (int) Math.pow(2, m);
    int mx = u[1-1].intValue();
    int nu = (int) Math.pow(2, mx);
    int n2 = n/2;
    int n21 = n2+1;
    int n4 = n/4;
    int ku = n/2;
    int kn = ku+nu;
    
    // Check if input parameters are invalid.
    if ((is != 1 && is != -1) || m < 3 || m > mx) 
    {
      throw new ArithmeticException(
        "CRFFTZ: Either U has not been initialized, or else " + 
        "one of the input parameters is invalid " +
         is + " " + m + " " + mx);
    }
    MPReal realIS = new MPReal(is);
    // Construct the input to CFFTZ.
    y[1-1] = x[1-1].add(x[n21-1]).multiply(POINTFIVE);
    y[n2+1-1] = x[1-1].subtract(x[n21-1]).multiply(POINTFIVE);
    y[n4+1-1] = x[n4+1-1];
    y[n4+n2+1-1] = realIS.negate().multiply(x[n4+n2+2-1]);
    
    // This loop is vectorizable.
    
    int k;
    MPReal x11, x12, x21, x22, a1, a2,b1,b2,u1,u2,t1,t2;
    for (k = 2; k <= n4; k++) 
    {
      x11 = x[k-1];
      x12 = x[k+n21-1];
      x21 = x[n2+2-k-1];
      x22 = x[n+3-k-1];
      a1 = x11.add(x21);
      a2 = x11.subtract(x21);
      b1 = x12.add(x22);
      b2 = x12.subtract(x22);
      u1 = u[k+ku-1];
      u2 = realIS.multiply(u[k+kn-1]);
      t1 = u1.multiply(b1).add(u2.multiply(a2));
      t2 = u1.multiply(a2).subtract(u2.multiply(b1));
      y[k-1] = a1.subtract(t1).multiply(POINTFIVE);
      y[k+n2-1] = b2.add(t2).multiply(POINTFIVE);
      y[n2+2-k-1] = a1.add(t1).multiply(POINTFIVE);
      y[n+2-k-1] = b2.negate().add(t2).multiply(POINTFIVE);
    }
    
    // Perform a normal N/2-point FFT on Y.
    cfftz(is, m-1, u, y, x);
    
    // Copy Y to X such that Y(k) = X(2k-1) + i X(2k).
    // This loop is vectorizable.
    
    for (k = 1; k <= n2; k++) 
    {
      x[2*k-1-1] = y[k-1];
      x[2*k-1] = y[k+n2-1];
    }
  }
  
  /*
  * Computes the 2^M-point complex-to-complex FFT of X using an algorithm due
  * to Swarztrauber, coupled with some fast methods for performing power-of-
  * two matrix transpositions (see article by DHB in Intl. J. of Supercomputer
  * Applications, Spring 1988, p. 82 - 87). This is the radix 2 version.
  * X is both the input and the output array, while Y is a scratch array.
  * Both X and Y must be dimensioned with 2 * N real cells, where N = 2^M.
  * The data in X are assumed to have real and imaginary parts separated
  * by N cells.  Before calling CFFTZ to perform an FFT, the array U must be
  * initialized by calling CFFTZ with IS set to 0 and M set to MX, where MX is
  * the maximum value of M for any subsequent call.  U must be dimensioned
  * with at least 2 * NX real cells, where NX = 2^MX.  M must be at least two.
  * David H. Bailey     May 4, 1988
  */
  static void cfftz(final int is, final int m, MPReal u[], MPReal x[], MPReal y[])
  {
    int n = (int) Math.pow(2, m);
    if (0 == is) 
    {
      
      // Initialize the U array with sines and cosines in a manner that permits
      // stride one access at each FFT iteration.
      
      int nu = n;
      u[1-1] = new MPReal(m);
      int ku = 2;
      int kn = ku+nu;
      int ln = 1;
      
      MPReal t, ti;
      for (int j = 1; j <= m; j++) 
      {
        t = MPReal.mppic.divide(new MPReal(ln));
        
        // This loop is vectorizable.
        for (int i = 0; i < ln; i++) 
        {
          ti = t.multiply(new MPReal(i));
          u[i+ku-1] = new MPReal();
          u[i+kn-1] = new MPReal();
          ti.cssnf(u[i+ku-1], u[i+kn-1]);
        }
        
        ku += ln;
        kn = ku+nu;
        ln *= 2;
      }
      return;
    }
    
    // Check if input parameters are invalid.
    int mx = u[1-1].intValue();
    if ((is != 1 && is != -1) || m < 2 || m > mx) 
    {
      throw new ArithmeticException(
        "CFFTZ: Either U has not been initialized, " +
        "or else one of the input parameters is invalid "
       + is + m + mx);
    }
    
    /*
    * A normal call to CFFTZ starts here.  M1 is the number of the first variant
    * radix-2 Stockham iterations to be performed.  The second variant is faster
    * on most computers after the first few iterations, since in the second
    * variant it is not necessary to access roots of unity in the inner DO loop.
    * Thus it is most efficient to limit M1 to some value.  For many vector
    * computers, the optimum limit of M1 is 6.  For scalar systems, M1 should
    * probably be limited to 2.
    */
    int m1 = Math.min(m/2, 2);
    int m2 = m-m1;
    int n2 = (int) Math.pow(2, m1);
    int n1 = (int) Math.pow(2, m2);
    int i;
    
    // Perform one variant of the Stockham FFT.
    
    int l;
    for (l = 1; l <= m1; l += 2) 
    {
      fftz1(is, l, m, u, x, y);
      if (l == m1)
        break;       
      fftz1(is, l+1, m, u, y, x);
    }
    
    if(l <= m1)
    {
      trans(n1, n2, y, x);
      
      // Perform second variant of the Stockham FFT from X to Y and Y to X.
      for (l = m1+1; l <= m; l += 2) 
      {
        fftz2(is, l, m, u, x, y);
        if (l == m) break;
        fftz2(is, l+1, m, u, y, x);
      }

      if(l > m)
        return;
      
    }
    else
    {
      
      // Perform a transposition of X treated as a N2 x N1 x 2 matrix.
      trans(n1, n2, x, y);
      
      // Perform second variant of the Stockham FFT from Y to X and X to Y.
      for (l = m1+1; l <= m; l += 2) 
      {
        fftz2(is, l, m, u, y, x);
        if (l == m) return;
        fftz2(is, l+1, m, u, x, y);
      }
    }
    // Copy Y to X.
    for (i = 0; i < 2*n; i++)
      x[i] = y[i];
    return;
  }
  
  /**
  *  Performs the L-th iteration of the first variant of the Stockham FFT.
  */
  static void fftz1(final int is, final int l, final int m, final MPReal u[], MPReal x[], MPReal y[])   
  {
    // Set initial parameters.
    
    int n = (int) Math.pow(2, m);
    int mx = u[1-1].intValue();
    int nu = (int) Math.pow(2, mx);
    int n1 = n/2;
    int lk = (int) Math.pow(2, l-1);
    int li = (int) Math.pow(2, m-l);
    int lj = 2*li;
    int ku = li+1;
    int kn = ku+nu;
    MPReal realIS = new MPReal(is);
    MPReal u1, u2, x11, x12, x21, x22, t1, t2;
    for (int k = 0; k < lk; k++) 
    {
      int i11 = k*lj+1;
      int i12 = i11+li;
      int i21 = k*li+1;
      int i22 = i21+n1;
     
      // This loop is vectorizable.
      for (int i = 0; i < li; i++) 
      {
        u1 = u[ku+i-1];
        u2 = realIS.multiply(u[kn+i-1]);
        x11 = x[i11+i-1];
        x12 = x[i11+i+n-1];
        x21 = x[i12+i-1];
        x22 = x[i12+i+n-1];
        t1 = x11.subtract(x21);
        t2 = x12.subtract(x22);
        y[i21+i-1] = x11.add(x21);
        y[i21+i+n-1] = x12.add(x22);
        y[i22+i-1] = u1.multiply(t1).subtract(u2.multiply(t2));
        y[i22+i+n-1] = u1.multiply(t2).add(u2.multiply(t1));
      }
    }
  }
  
  /**
  * Performs the L-th iteration of the second variant of the Stockham FFT.
  */ 
  static void fftz2(final int is, final int l, final int m, final MPReal u[], MPReal x[], MPReal y[])    
  {
    // Set initial parameters. 
    int n = (int) Math.pow(2, m);
    int mx = u[1-1].intValue();
    int nu = (int) Math.pow(2, mx);
    int n1 = n/2;
    int lk = (int) Math.pow(2, l-1);
    int li = (int) Math.pow(2, m-l);
    int lj = 2*lk;
    int ku = li+1;
    MPReal realIS = new MPReal(is);
    MPReal u1, u2, x11, x12, x21, x22, t1, t2;
    for (int i = 0; i < li; i++) 
    {
      int i11 = i*lk+1;
      int i12 = i11+n1;
      int i21 = i*lj+1;
      int i22 = i21+lk;
      u1 = u[ku+i-1];
      u2 = realIS.multiply(u[ku+i+nu-1]);
      
      // This loop is vectorizable.
      for (int k = 0; k < lk; k++) 
      {
        x11 = x[i11+k-1];
        x12 = x[i11+k+n-1];
        x21 = x[i12+k-1];
        x22 = x[i12+k+n-1];
        t1 = x11.subtract(x21);
        t2 = x12.subtract(x22);
        y[i21+k-1] = x11.add(x21);
        y[i21+k+n-1] = x12.add(x22);
        y[i22+k-1] = u1.multiply(t1).subtract(u2.multiply(t2));
        y[i22+k+n-1] = u1.multiply(t2).add(u2.multiply(t1));
      }
    }
  }
  
    
  /*
  * Performs a transpose of the vector X, returning the result in Y.  X is
  * treated as a N1 x N2 complex matrix, and Y is treated as a N2 x N1 complex
  * matrix.  The complex data is assumed stored with real and imaginary parts
  * separated by N1 x N2 locations.
  */
static void trans(final int n1, final int n2, final MPReal x[], MPReal y[])
{
  final int na = 32;
  final int nc = 32;
  int i, j;
  
  int n = n1*n2;
  if (n1 >= n2)
  {
    // Scheme 1:  Perform a simple transpose in the usual way.
    
    for (j = 0; j < n2; j++) 
    {
      int j1 = j+1;
      int j2 = j*n1+1;
      
      // This loop is vectorizable.    
      for (i = 0; i < n1; i++) 
      {
        y[i*n2+j1-1] = x[i+j2-1];
        y[i*n2+j1+n-1] = x[i+j2+n-1];
      }
    }
    return;
  }
  // Scheme 2:  Perform a simple transpose with the loops reversed.
  for (i = 0; i < n1; i++) 
  {
    int i1 = i*n2+1;
    int i2 = i+1;
    
    // This loop is vectorizable.
    
    for (j = 0; j < n2; j++) 
    {
      y[j+i1-1] = x[j*n1+i2-1];
      y[j+i1+n-1] = x[j*n1+i2+n-1];
    }
  }
}
  
  
}

