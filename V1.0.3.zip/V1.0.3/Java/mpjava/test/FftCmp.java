import mpfun.*;

/*
*   Performs real-to-complex and complex-to-real FFT routines using routines
*   RCFFTC, CRFFTC and CFFTC.  These routines use double complex data.
*   David H. Bailey     June 6, 1994
*
*   Translated into Java.
*   Herman Harjono
*   October 20, 1998.
*/
public final class FftCmp 
{
  static final MPReal ZERO = new MPReal(0);
  static final MPReal TWO = new MPReal(2);
  static final MPReal ONE = new MPReal(1);

  public static void  main(String args[])
  {
    final int     m = 8;
    final int     n = 256;
    final int     it = 10;
    final double  aa = 1220703125.0;
    final double  ss = 314159265.0;
    MPReal     x[]= new MPReal[n+2], rn, se;
    MPComplex    u[] = new MPComplex[n], 
      y[] = new MPComplex[n/2+1], z[] = new MPComplex[n/2+1];
    double    s[] = new double[n];
    
    //   Initialize.  The SECOND function is assumed to be the timing function
    //   on the given computer.  Change here and below if another name is used.
    
    rn = ONE.divide(new MPReal(n));
    double rr = 0.0;
    double xx=0;
    xx = vranl(0, xx, aa, s);

    xx = ss;
    cfftc(0, m, u, y, z);
    int yy;
      
    //  Perform IT iterations.
    for (int ii = 1; ii <= it; ii++) 
    {
      xx = vranl(n, xx, aa, s);
      int i;
      for (i = 0; i < n; i++) x[i] = new MPReal(s[i]);
      
      rcfftc(-1, m, u, x, y, z);
      crfftc(1, m, u, z, y, x);
      se = ZERO;
      for (i = 0; i < n; i++) 
      {
        se = se.add(rn.multiply(x[i]).subtract(new MPReal(s[i])).pow(2));

      }
   
      se = se.divide(new MPReal(n)).sqrt();
      System.out.print("Iteration " + ii + "   "
      + "Error =\n" + se);

      if (se.compareTo(MPReal.mpeps) > 0) 
      {
        System.out.println("*** Error detected:");
        System.exit(1);
      }
    }
    
    System.out.println("Test passed.");
  }

  static double aint(double x)
  {
    if (Math.abs(x) < 1.0) return 0.0;
    return Math.floor(Math.abs(x))*(x >= 0 ? 1.0 : -1.0);
  }
 
  
   static int ks = 0;
   static double r23, r46, t23, t46;
 
  /*
  * This routine generates N uniform pseudorandom double precision numbers in
  * the range (0, 1) by using the linear congruential generator
  *
  * x_{k+1} = a x_k  (mod 2^46)
  *
  * where 0 < x_k < 2^46 and 0 < a < 2^46.  This scheme generates 2^44 numbers
  * before repeating.  The argument A is the same as 'a' in the above formula,
  * and X is the same as x_0.  A and X must be odd double precision integers
  * in the range (1, 2^46).  The N results are placed in Y and are normalized
  * to be between 0 and 1.  X is updated to contain the new seed, so that
  * subsequent calls to VRANL using the same arguments will generate a
  * continuous sequence.  If N is zero, only initialization is performed, and
  * the variables X, A and Y are ignored.
  *
  * This routine is the standard version designed for scalar or RISC systems.
  * However, it should produce the same results on any single processor
  * computer with at least 48 mantissa bits in double precision floating point
  * data.  On Cray systems, double precision should be disabled.

  * David H. Bailey     October 26, 1990
  */
  static double vranl(final int n, double x, final double a, double y[])
  {
    
    //  If this is the first call to VRANL, compute R23 = 2 ^ -23, R46 = 2 ^ -46,
    //  T23 = 2 ^ 23, and T46 = 2 ^ 46.  See comments in RANDLC.
    if (0 == ks || 0 == n) 
    {
      r23 = r46 = t23 = t46 = 1.0;
      int i;
      for (i = 0; i < 23; i++) 
      {
        r23 *= 0.5;
        t23 *= 2.0;
      }
      for (i = 0; i < 46; i++) 
      {
        r46 *= 0.5;
        t46 *= 2.0;
      }
      
      ks = 1;
      if (n == 0) return x;
    }
    
    // Break A into two parts such that A = 2^23 * A1 + A2 and set X = N.
    
    double t1 = r23*a;
    double a1 = aint(t1);
    double a2 = a-t23*a1;
    
    // Generate N results.   This loop is not vectorizable.
    for (int i = 0; i < n; i++) 
    {
      // Break X into two parts such that X = 2^23 * X1 + X2, compute
      // Z = A1 * X2 + A2 * X1  (mod 2^23), and then
      // X = 2^23 * Z + A2 * X2  (mod 2^46).
      
      t1 = r23*x;
      double x1 = aint(t1);
      double x2 = x-t23*x1;
      t1 = a1*x2+a2*x1;
      double t2 = aint(r23*t1);
      double z = t1-t23*t2;
      double t3 = t23*z+a2*x2;
      double t4 = aint(r46*t3);
      x = t3-t46*t4;
      y[i] = r46*x;
    }
    return x;
  }
  
  /*
  * Computes the N-point real-to-complex FFT of X, where N = 2^M.   This 
  * uses an algorithm due to Swarztrauber, coupled with some fast methods of
  * methods of performing power-of-two matrix transforms.  X is the input
  * array, Y is a scratch array, and Z is the output array.  X must be
  * dimensioned with N + 2 real cells.  Y, and Z must be dimensioned with N/2+1
  * complex cells.  If desired, X and Y or X and Z may be the same array in
  * the calling program.  Before calling RCFFTC to perform an FFT, the array U
  * must be initialized by calling CFFTC with IS set to 0 and M set to MX,
  * where MX is the maximum value of M for any subsequent call.  U must be
  * dimensioned with at least 2 * N real cells.  M must be at least two.
  */
  static void rcfftc(final int is, final int m, MPComplex u[], MPReal x[],
    MPComplex y[], MPComplex z[])
  {
    MPComplex c0, c1, y0, y1;
    
    //   Set initial parameters.
    int n = (int) Math.pow(2, m);
    int mx = u[0].intValue();
    int n2 = n/2;
    int n21 = n2+1;
    int n22 = n2+2;
    int n4 = n/4;
    int n41 = n4+1;
    int ku = n/2+1;
    
    //   Check if input parameters are invalid.
    if ((is != 1 && is != -1) || m < 3 || m > mx) 
    {
      System.out.println("RCFFTC: Either U has not been initialized, or else " +
      "one of the input parameters is invalid " + 
      + is  +  n  +  mx);
      System.exit(1);
    }
    
    //   Copy X to Y such that Y(k) = X(2k-1) + i X(2k).
    int k;
    for (k = 1; k <= n2; k++)
      y[k-1] = new MPComplex(x[2*k-1-1], x[2*k-1]);
    
    //   Perform a normal N/2-point FFT on Y.
    cfftc(is, m-1, u, y, z);
    
   
    //   Reconstruct the FFT of X.
    final MPComplex CTWO = new MPComplex(2);
    z[1-1] = new MPComplex(TWO.multiply(y[1-1].aimag().add(new MPReal(y[1-1]))));
    z[n41-1] = CTWO.multiply(new MPComplex(new MPReal(y[n41-1]), 
      y[n41-1].aimag().multiply (new MPReal(is)) ));
    z[n21-1] = new MPComplex(
      TWO.multiply((new MPReal(y[1-1])).subtract(y[1-1].aimag())) );
    
    if (1 == is) 
    {
      for (k = 2; k <= n4; k++) 
      {
        y0 = y[k-1];
        y1 = y[n22-k-1].conjg();
        c0 = y0.add(y1);
        c1 = y0.subtract(y1).multiply(u[ku+k-1]);
        z[k-1] = c0.add(c1);
        z[n22-k-1] = c0.subtract(c1).conjg();
      }
    }
    else 
    {
      for (k = 2; k <= n4; k++) 
      {
        y0 = y[k-1];
        y1 = y[n22-k-1].conjg();
        c0 = y0.add(y1);
        c1 = u[ku+k-1].conjg().multiply(y0.subtract(y1));
        z[k-1] = c0.add(c1);
        z[n22-k-1] = c0.subtract(c1).conjg();
      }
    }
  }
  
  /*
  *   Computes the N-point complex-to-real FFT of X, where N = 2^M.   This 
  *   uses an algorithm due to Swarztrauber, coupled with some fast methods of
  *   methods of performing power-of-two matrix transforms.  X is the input
  *   array, Y is a scratch array, and Z is the output array.  X and Y must be
  *   dimensioned with N/2+1 complex cells.  Z must be dimensioned with N + 2
  *   real cells.  If desired, X and Y or X and Z may be the same array in
  *   the calling program.  Before calling CRFFTC to perform an FFT, the array U
  *   must be initialized by calling CFFTC with IS set to 0 and M set to MX,
  *   where MX is the maximum value of M for any subsequent call.  U must be
  *   dimensioned with at least 2 * N real cells.  M must be at least two.
  */
  static void crfftc(final int is, final int m, MPComplex u[], MPComplex x[],
    MPComplex y[], MPReal z[])
  {
    MPComplex c0, c1, x0, x1;
    
    // Set initial parameters.
    int n = (int) Math.pow(2,m);
    int mx = u[0].intValue();
    int n2 = n/2;
    int n21 = n2+1;
    int n22 = n2+2;
    int n4 = n/4;
    int n41 = n4+1;
    int ku = n/2+1;
    
    // Check if input parameters are invalid.
    if ((is != 1 && is != -1) || m < 3 || m > mx) 
    {
      System.out.println("CRFFTC: Either U has not been initialized, or else " +
      "one of the input parameters is invalid " +
       is + n + mx);;
      System.exit(1);
    }
    
    final MPComplex POINTFIVE = new MPComplex(0.5);
    // Construct the input to CFFTC.
    y[1-1] = POINTFIVE.multiply(
      new MPComplex((new MPReal(x[1-1])).add(new MPReal(x[n21-1])),
      (new MPReal(x[1-1])).subtract(new MPReal(x[n21-1]))));
    y[n4+1-1] = new MPComplex(new MPReal(x[n41-1]), (new MPReal(is)).negate()
      .multiply(x[n41-1].aimag()) ) ;
    if (1 == is) 
    {
      for (int k = 2; k <= n4; k++) 
      {
        x0 = x[k-1];
        x1 = x[n22-k-1].conjg();
        c0 = x0.add(x1);
        c1 = u[ku+k-1].multiply(x0.subtract(x1));
	y[k-1] = POINTFIVE.multiply(c0.add(c1));
	y[n22-k-1] = POINTFIVE.multiply(c0.subtract(c1).conjg());
      }
    }
    else 
    {
      for (int k = 2; k <= n4; k++) 
      {
        x0 = x[k-1];
        x1 = (x[n22-k-1]).conjg();
        c0 = x0.add(x1);
        c1 = x0.subtract(x1).multiply(u[ku+k-1].conjg());
        y[k-1] = POINTFIVE.multiply(c0.add(c1));
        y[n22-k-1] = POINTFIVE.multiply(c0.subtract(c1).conjg());

      }
    }

    //   Perform a normal N/2-point FFT on Y.
    cfftc(is, m-1, u, y, x);
    
    //   Copy Y to Z such that Y(k) = Z(2k-1) + i Z(2k).
    for (int k = 1; k <= n2; k++) 
    {
      z[2*k-1-1] = new MPReal(y[k-1]);
      z[2*k-1] = y[k-1].aimag();
    }
  }
  
  /*
  *  Computes the N-point complex-to-complex FFT of X, where N = 2^M.   This 
  *  uses an algorithm due to Swarztrauber, coupled with some fast methods of
  *  methods of performing power-of-two matrix transforms.  X is the input
  *  array, Y is a scratch array, and Z is the output array.  X, Y, and Z must
  *  be dimensioned with N complex cells.  If desired, X and Y or X and Z may
  *  be the same array in the calling program.  Before calling CFFTC to perform
  *  an FFT, the array U must be initialized by calling CFFTC with IS set to 0
  *  and M set to MX, where MX is the maximum value of M for any subsequent
  *  call.  U must be dimensioned with at least 2 * N real cells.  M must be at
  *  least two.
  */
  static void cfftc(final int is, final int m, MPComplex u[], MPComplex x[],
    MPComplex y[])
  {
    MPReal t, ti, t1 = new MPReal(0), t2 = new MPReal(0);
    final int n = 256;
    MPComplex z[] = new MPComplex[n];
    int i;
    
    if (0 == is) 
    {
      
      // Initialize the U array with sines and cosines in a manner that permits
      // stride one access at each radix-4 FFT iteration.  If M is odd, then the
      // final set of results are for a radix-2 FFT iteration.
      
      u[1-1] = new MPComplex(m);
      int ku = 2;
      int ln = 1;
      
      for (int j = 1; j <= m; j++) 
      {
        t = MPReal.mppic.divide(new MPReal(ln));
        for (i = 0; i < ln; i++) 
        {
          ti = t.multiply(new MPReal(i));
          ti.cssnf(t1, t2);
          u[i+ku-1] = new MPComplex(t1, t2);
        }
        
        ku += ln;
        ln *= 2;
      }
      return;
    }
    
    // Check if input parameters are invalid.
    int mx = u[1-1].intValue();
    if ((is != 1 && is != -1) || m < 2 || m > mx) 
    {
      System.out.println("CFFTC: Either U has not been initialized, or else " +
        "one of th input parameters is invalid " +
        is + n + mx);
      System.exit(-1);
    }
    
    // A normal call to CFFTZ starts here.  M1 is the number of the first variant
    // radix-2 Stockham iterations to be performed.  The second variant is faster
    // on most computers after the first few iterations, since in the second
    // variant it is not necessary to access roots of unity in the inner DO loop.
    // Thus it is most efficient to limit M1 to some value.  For many vector
    // computers, the optimum limit of M1 is 6.  For scalar systems, M1 should
    // probably be limited to 2.
    
    int m1 = Math.min(m/2, 2);
    int m2 = m-m1;
    int n2 = (int) Math.pow(2, m1);
    int n1 = (int) Math.pow(2, m2);
    boolean broken = false;
    //   Perform the first variant of the radix-2 Stockham FFT.
    int l;
    for (l = 1; l <= m1; l += 2) 
    {
      fftc1(is, l, m, u, x, y);
      if (l == m1)
      {
        broken = true;
        break;
      }
      fftc1(is, l+1, m, u, y, x);
    }
    
    if(broken)
    {
      trans(n1, n2, y, x);
      
      //  Perform the second variant of the radix-2 Stockham FFT.
      for (l = m1+1; l <= m; l += 2) 
      {
        fftc2(is, l, m, u, x, y);
        if (l == m) 
        {
          for (i = 0; i < n; i++) x[i] = y[i];
          return;
        }
        fftc2(is, l+1, m, u, y, x);
      }
      
      return;
    }
    
    trans(n1, n2, x, y);
    
    //  Perform the second variant of the radix-2 Stockham FFT.
    for (l = m1+1; l <= m; l += 2) 
    {
      fftc2(is, l, m, u, y, x);
      if (l == m) return;
      fftc2(is, l+1, m, u, x, y);
    }
    
    //  Copy Y to X if the last operation above stored into Y.
    for (i = 0; i < n; i++) x[i] = y[i];
  }
  

  /*
  *  Performs the L-th iteration of the first variant of the radix-2 Stockham
  *  FFT.  Complex version.
  */
  static void fftc1(final int is, final int l, final int m, 
    final MPComplex u[], MPComplex x[], MPComplex y[])
  {
    MPComplex uj, x1, x2;
    
    //   Set initial parameters.
    int n = (int) Math.pow(2, m);
    int ni = n/2;
    int lk = (int) Math.pow(2, l-1);
    int lj = ni/lk;
    int ku = lj+1;
    
    for (int k = 0; k < lk; k++) 
    {
      int k11 = 2*k*lj+1;
      int k12 = k11+lj;
      int k21 = k*lj+1;
      int k22 = k21+ni;
      
      if (1 == is) 
      {
        for (int j = 0; j < lj; j++) 
        {
          uj = u[ku+j-1];
          x1 = x[k11+j-1];
          x2 = x[k12+j-1];
          y[k21+j-1] = x1.add(x2);
          y[k22+j-1] = x1.subtract(x2).multiply(uj);
        }
      }
      else 
      {
        for (int j = 0; j < lj; j++) 
        {
          uj = u[ku+j-1].conjg();
          x1 = x[k11+j-1];
          x2 = x[k12+j-1];
          y[k21+j-1] = x1.add(x2);
          y[k22+j-1] = x1.subtract(x2).multiply(uj);
        }
      }
    }
  }
  

 /*
  *  Performs the L-th iteration of the second variant of the radix-2 Stockham
  *  FFT.  Complex version.
  */
  static void fftc2(final int is, final int l, final int m, 
    final MPComplex u[], MPComplex x[], MPComplex y[])    
  {
    MPComplex uj, x1, x2;
    
    //   Set initial parameters.
    int n = (int) Math.pow(2, m);
    int ni = n/2;
    int lk = (int) Math.pow(2, l-1);
    int lj = ni/lk;
    int ku = lj+1;
    
    for (int j = 0; j < lj; j++) 
    {
      int j11 = j*lk+1;
      int j12 = j11+ni;
      int j21 = 2*j*lk+1;
      int j22 = j21+lk;
      uj = u[ku+j-1];
      if (-1 == is) uj = uj.conjg();
      
      for (int k = 0; k < lk; k++) 
      {
        x1 = x[j11+k-1];
        x2 = x[j12+k-1];
        y[j21+k-1] = x1.add(x2);
        y[j22+k-1] = x1.subtract(x2).multiply(uj);
      }
    }
  }
  

  /*
  *   Performs a transpose of the vector X, returning the result in Y.  X is
  *   treated as a N1 x N2 complex matrix, and Y is treated as a N2 x N1 complex
  *   matrix.  The complex data is assumed stored with real and imaginary parts
  *   interleaved as in the COMPLEX type.
  *
  *  David H. Bailey      April 28, 1987
  */
  static void trans(final int n1, final int n2, final MPComplex x[], MPComplex y[])
  {
    int n = n1*n2;
    int i, j;
    
    //   Perform one of three techniques, depending on N.  The best strategy varies
    //  with the computer system.  This strategy is best for scalar systems.
    
    if (n1 >= n2)
    {
      for (j = 0; j < n2; j++) 
        for (i = 0; i < n1; i++) 
          y[i*n2+j+1-1] = x[i+j*n1+1-1];
      return;
    }
    
   
    //  Scheme 2:  Perform a simple transform with the loops reversed.  This is
    //  usually the best on vector computers if N1 is odd, or if both N1 and N2 are
    //  small, and N2 is larger than N1.
    
    for (i = 0; i < n1; i++) 
      for (j = 0; j < n2; j++) 
        y[j+i*n2+1-1] = x[j*n1+i+1-1];    
  }
  
  
}

