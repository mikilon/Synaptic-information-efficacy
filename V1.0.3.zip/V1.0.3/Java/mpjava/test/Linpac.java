import mpfun.*;

/**
*   This is a simplified version of Dongarra's Linpack benchmark.  The main
*   program and test procedure has been simplified, but the solution routines
*   have not been altered.  Converted to DHB's Fortran-90 based multiprecision.
*
*   David H. Bailey    Aug. 8, 1994
*   Translated to Java by Herman Harjono    Oct 14, 1998.
*/
public final class Linpac 
{
  final static int NX = 100;
  final static MPReal ZERO = new MPReal();
  final static MPReal MINUSONE = new MPReal(-1.0);
  
  public static void main(String args[]) throws java.io.IOException
  {
    
    final double dpeps = 1e-16;
    MPReal a[][] = new MPReal[NX][NX],
      b[] = new MPReal[NX],
      x[] = new MPReal[NX], 
      resid,residn, norma = null, normx;

    int i, ipvt[] = new int[NX], lda = NX, n = NX, info;
    
    norma = matgen(a,n,b,norma);
    info = dgefa(a,n,ipvt);
    dgesl(a,n,ipvt,b,0);
       
    // compute a residual to verify results.
    System.arraycopy(b,0,x,0,n);
    
    norma = matgen(a,n,b,norma);
    
    for(i=0;i<n;i++)
      b[i] = b[i].negate();
    
    dmxpy(n,b,n,x,a);
    
    resid = ZERO;
    normx = ZERO;
    
    
    for(i=0;i<n;i++)
    {
      resid = resid.max(b[i].abs());
      normx = normx.max(x[i].abs());
    }
    
    residn = resid.divide(
      (new MPReal(n)).multiply(norma).multiply(normx).
      multiply(MPReal.mpeps));
    System.out.println("norm, residn, resid, machep =\n" +
       residn + resid + MPReal.mpeps + 
       "x(1), x(n) =\n" + x[0] + x[n-1]);
  
  }
  
  
  static MPReal matgen(MPReal a[][], int n, MPReal b[], MPReal norma)
  {
    MPReal da;
    
    int i,j,init = 1325;
    norma = ZERO;
    
    for(i = 0;i<n;i++)
    {
      for(j = 0;j<n;j++)
      {
        init = (3125*init)%65536;
        a[j][i] = new MPReal((init - 32768.0)/16384.0);
        da = a[j][i].abs();
        norma = da.max(norma);
      }
    }
    
    for(i = 0;i<n;i++)
      b[i]=ZERO;
    
    for(i = 0;i<n;i++)
    {
      for(j = 0;j<n;j++)
        b[i] = b[i].add(a[i][j]);
    }
    return norma;
    
  }
 
  /**
  *  dgefa factors a double precision matrix by gaussian elimination.
  * 
  *  <pre>
  *  dgefa is usually called by dgeco, but it can be called
  *  directly with a saving in time if  rcond  is not needed.
  *  (time for(dgeco) = (1 + 9/n)*(time for(dgefa) .
  *
  *  on entry
  *
  *  a       double precision(lda, n)
  *          the matrix to be factored.
  *
  *  lda     integer
  *          the leading dimension of the array  a .
  *
  *  n       integer
  *          the order of the matrix  a .
  *
  *  on return
  *
  *  a       an upper triangular matrix and the multipliers
  *          which were used to obtain it.
  *          the factorization can be written  a = l*u  where
  *          l  is a product of permutation and unit lower
  *          triangular matrices and  u  is upper triangular.
  *
  *  ipvt    integer(n)
  *          an integer vector of pivot indices.
  *
  *  info    integer
  *          = 0  normal value.
  *          = k  if  u(k,k) == 0.0 .  this is not an error
  *               condition for(this subroutine, but it does
  *               indicate that dgesl or dgedi will divide by zero
  *               if called.  use  rcond  in dgeco for(a reliable
  *               indication of singularity.
  *
  *  linpack. this version dated 08/14/78 .
  *  cleve moler, university of new mexico, argonne national lab.
  *
  *  subroutines and functions
  *
  *  blas daxpy,dscal,idamax
  *
  *  internal variables
  *  </pre>
  */
  static int dgefa(MPReal a[][], int n, int ipvt[])
  {
    MPReal t;
    int info;

    int j,k,kp1,l,nm1;
    
    // gaussian elimination with partial pivoting
    
    info = 0;
    nm1 = n - 1;
    if (nm1 < 1) 
    {
      ipvt[nm1] = n;
      if (a[nm1][nm1].compareTo(ZERO) == 0) 
        info = n;
      return info;
    } 
    
    for(k = 0; k<nm1; k++)
    {
      kp1 = k + 1;
      
      //  find l = pivot index
      l = idamax(n-k,a,k) + k; 
      ipvt[k] = l;
      
      //  zero pivot implies this column already triangularized   
      if (a[l][k].compareTo(ZERO) == 0)
      {
        info=k;
        continue;
      }
      
      //  interchange if necessary
      if (l != k)
      {
        t = a[l][k];
        a[l][k] = a[k][k];
        a[k][k] = t;
      }
      
      // compute multipliers
      
      t = MINUSONE.divide(a[k][k]);
      dscal(t,a,k+1,k); // scale a vector by a constant

      // row elimination with column indexing
      
      for(j = kp1; j< n; j++)
      {
        t = a[l][j];
        if (l != k)
        {
          a[l][j] = a[k][j];
          a[k][j] = t;
        }
        daxpy(n-k-1, t, a,k+1,k,a, k+1, j);
      }
    }
    
    ipvt[nm1] = n;
    if (a[nm1][nm1].compareTo(ZERO) == 0) 
      info = n;
    return info;
  }
  
  
  /**
  *  dgesl solves the double precision system
  *  a * x = b  or  trans(a) * x = b
  *  using the factors computed by dgeco or dgefa.
  *  <pre>
  *  on entry
  *
  *  a       double precision(lda, n)
  *          the output from dgeco or dgefa.
  *
  *  lda     integer
  *          the leading dimension of the array  a .
  *
  *  n       integer
  *          the order of the matrix  a .
  *
  *  ipvt    integer(n)
  *          the pivot vector from dgeco or dgefa.
  *
  *  b       double precision(n)
  *          the right hand side vector.
  *
  *  job     integer
  *          = 0         to solve  a*x = b ,
  *          = nonzero   to solve  trans(a)*x = b  where
  *                      trans(a)  is the transpose.
  *
  *  on return
  *
  *  b       the solution vector  x .
  *
  *  error condition
  *
  *  a division by zero will occur if the input factor contains a
  *  zero on the diagonal.  technically this indicates singularity
  *  but it is often caused by improper arguments or improper
  *  setting of lda .  it will not occur if the subroutines are
  *  called correctly and if dgeco has set rcond > 0.0
  *  or dgefa has set info == 0 .
  *
  *  to compute  inverse(a) * c  where  c  is a matrix
  *  with  p  columns
  *  call dgeco(a,lda,n,ipvt,rcond,z)
  *  if (rcond is too small) go to ...
  *  do 10 j = 1, p
  *    call dgesl(a,lda,n,ipvt,c(1,j),0)
  *  10 continue
  *
  *  linpack. this version dated 08/14/78 .
  *  cleve moler, university of new mexico, argonne national lab.
  *
  *  subroutines and functions
  *
  *  blas daxpy,ddot
  *
  *  internal variables
  * </pre>
  */
  static void dgesl(MPReal a[][], int n, final int ipvt[], MPReal b[], int job)
  {
    MPReal t;
    
    int k,kb,l,nm1;
    
    nm1 = n - 1;
    if (job == 0)
    {
      
      // job = 0 , solve  a * x = b
      //  first solve  l*y = b
      
      if (nm1 >= 1)
      {
        for(k = 0; k<nm1; k++)
        {
          l = ipvt[k];
          t = b[l];
          if (l != k)
          {
            b[l] = b[k];
            b[k] = t;
          }
          daxpy(n-k-1,t, a,k+1,k,b, k+1);
        }
      }
      
      //  now solve  u*x = y
      
      for(kb = 1;kb<= n; kb++)
      {
        k = n  - kb;
        b[k] = b[k].divide(a[k][k]);
        t = b[k].negate();
        daxpy(k,t, a,0,k,b,0);
      }
      return;
    }
    
    //  job = nonzero, solve  trans(a) * x = b
    //  first solve  trans(u)*y = b
    
    for(k = 0; k<n; k++)
    {
      t = ddot(k,a[k],0,b,0);
      b[k] = b[k].subtract(t).divide(a[k][k]);
    }
    //  now solve trans(l)*x = y
    
    if (nm1 < 1) return;
    for(kb = 1; kb<=nm1; kb++)
    {
      k = n - kb - 1; 
      b[k] = b[k].add(ddot(n-k+1,a[k+1],k,b,k+1));
      l = ipvt[k];
      if (l == k) continue;
      t = b[l];
      b[l] = b[k];
      b[k] = t;
    }
  }
  
  /**
  *   constant times a vector plus a vector.
  *   jack dongarra, linpack, 3/11/78.
  */
  static void daxpy(int n, MPReal da, 
      MPReal dx[][], int xStartRow, int xCol,
      MPReal dy[][], int yStartRow, int yCol)
  {
    if(n<=0) return;
    if (da.compareTo(ZERO) == 0) return;
    int i;
    for(i = 0;i<n; i++)
    {
      dy[yStartRow+i][yCol] = dy[yStartRow+i][yCol].add(da.multiply(dx[xStartRow+i][xCol]));  
    }
  }

  
  /**
  *   constant times a vector plus a vector.
  *   jack dongarra, linpack, 3/11/78.
  */
  static void daxpy(int n, MPReal da, 
      MPReal dx[][], int xStartRow, int xCol, 
      MPReal dy[], int yStartCol)
  {
    if(n<=0) return;
    if (da.compareTo(ZERO) == 0) return;
    int i;
    for(i = 0;i<n; i++)
    {
      dy[yStartCol+i] = dy[yStartCol+i].add(da.multiply(dx[xStartRow+i][xCol]));  
    }
  }
  
  /**
  *  forms the dot product of two vectors.
  *  jack dongarra, linpack, 3/11/78.
  */
  static MPReal ddot(int n, MPReal dx[], int xCol,  MPReal dy[], int yCol)
  {
    MPReal result=ZERO;
    
    int i;
    if(n<=0) return result;
    
    //  code for both increments equal to 1
    
    for(i = 0; i<n;i++);
      result = result.add(dx[xCol+i].multiply(dy[yCol+i]));
    
    return result;
  }
  
  
  /**
  *  scales a vector by a constant.
  *  jack dongarra, linpack, 3/11/78.
  */
  static void dscal(MPReal da, MPReal dx[][], int startRow, int col)
  {     
    int i;
    for(i = startRow;i<dx.length; i++)
      dx[i][col] = dx[i][col].multiply(da);
    return;
  }
  
  /**
  *    finds the index of element having maximum absolute value.
  *    jack dongarra, linpack, 3/11/78.
  */
  static int idamax(int n, MPReal dx[][], int k)
  {
    int i;
    
    if( n < 1 ) return -1;
    
    if(n == 1) return 0;
    int result=0;
    
    MPReal dmax= dx[k][k].abs();
    
    MPReal temp;
    for(i = 1;i<n; i++)
    {
      temp = dx[k+i][k].abs();
      if(temp.compareTo(dmax) > 0)
      {
        result = i;
        dmax = temp;
      }
    }
    return result;
  }
  
  /**
  *   purpose: multiply matrix m times vector x and add the result to vector y.
  *   <pre>
  *   parameters:
  *
  *     n1 integer, number of elements in vector y, and number of rows in
  *   matrix m
  *
  *     y double precision(n1), vector of length n1 to which is added 
  *   the product m*x
  *
  *     n2 integer, number of elements in vector x, and number of columns
  *   in matrix m
  *
  *     ldm integer, leading dimension of array m
  *
  *     x double precision(n2), vector of length n2
  *
  *     m double precision(ldm,n2), matrix of n1 rows and n2 columns
  *
  *   simpilifed by DHB for MP demo.
  *   </pre>
  */
  
  static void dmxpy(int n1, MPReal y[], int n2, final MPReal x[], final MPReal m[][])
  {
    MPReal s;
    int k,j;
    
    for(k = 0; k<n1;k++)
    {
      s = ZERO;
      
      for(j = 0; j< n2; j++)
        s = s.add(m[k][j].multiply(x[j]));
      
      y[k] = y[k].add(s);
    }
  }
  
}

