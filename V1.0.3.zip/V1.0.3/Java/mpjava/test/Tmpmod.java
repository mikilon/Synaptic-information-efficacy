import mpfun.*;
//
//
// Tmpmod
//
//
public final class Tmpmod 
{
  public static void main(String args[]) throws java.io.IOException
  {    
    MPInt  ia,ib;
    MPComplex e;
    final int n = 25;
    MPReal a[] = new MPReal[n], b[] = new MPReal[n];
    final MPInt IFIVE = new MPInt(5);
    final MPReal RFIVE = new MPReal(5);
    final MPReal TWO = new MPReal(2);
    final MPReal ONE = new MPReal(1);

    // Character-to-MP assignment, generic MPREAL function, pi and e.
    MPReal x = new MPReal("1.234567890 1234567890 1234567890 e-100");
    
    MPReal ee = ONE.exp();
    System.out.print(x.toString() + MPReal.mppic.toString() + ee.toString());

    MPReal s = new MPReal(0.0);
    
    // Loop with subscripted MP variables.
    for (int i = 1; i <= n; i++) {
      a[i-1] = new MPReal(2*i+1);
      b[i-1] = a[i-1].multiply(TWO).multiply
			  ((a[i-1].add(ONE)));

      s = s.add(b[i-1].pow(2));
    }
    System.out.print(s);

    
    // Expression with mixed MPI and MPR entities.
    ia = new MPInt(s);
    ib = new MPInt(262144);
    s = s.add(new MPReal(327.25)).multiply(new MPReal(ia.mod(ib.multiply(new MPInt(4)))));
    System.out.print(s);
 
    // A complex square root reference.
    e = (new MPComplex(s.multiply(TWO), s)).sqrt();
    System.out.print(e);
  
    // External and intrinsic MP function references in expressions.
    s = dot(n, a, b);
    MPReal t = (s.sqrt().pow(2)).multiply(TWO);
    System.out.print(s.toString() + t.toString());
    
    s = s.divide(new MPReal(1048576.0));
    t = s.add(s.log().multiply(TWO));
    x = new MPReal(t.nint().multiply(IFIVE).add(new MPInt(3)));
    System.out.print(s.toString() + t.toString() + x.toString());
  
    // A deeply nested expression with function references.
    x = s.subtract(RFIVE).multiply(TWO).add(s).add
    ((t.subtract(RFIVE)).multiply(new MPReal(3))).multiply
    (s.log().cos().exp()); 
    System.out.print(x);
  
    // A special MP subroutine call (computes both cos and sin of S).
    MPReal y = new MPReal();
    s.cssnf(x, y);
    t = ONE.subtract(x.pow(2).add(y.pow(2)));
    
    // IF-THEN-ELSE construct involving MP variables.
    if (t.abs().compareTo(MPReal.mpeps) < 0)
      System.out.print(t);
    else
      System.out.print(MPReal.mpeps);   

  }

  static MPReal dot(int n, MPReal a[], MPReal b[])      
   {
      MPReal s = new MPReal();
      
      for (int i = 1-1; i < n; i++)
	 s = s.add(a[i].multiply(b[i]));
      return s;
   }

}


