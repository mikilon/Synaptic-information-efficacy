//import mpfun.*;
//
//
// Tmpmod
//
//
public final class Miki 
{
  public static void main(String args[]) throws java.io.IOException
  {    
    System.out.print("Hello world");
  }

}


