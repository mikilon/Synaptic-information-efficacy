import mpfun.*;
import timer.*;

public final class Rsa
{
  final static MPInt THREE = new MPInt(3);
  final static MPInt TWO = new MPInt(2);
  final static MPInt ONE = new MPInt(1);
  final static MPInt ZERO = new MPInt();
  
 
  static int idivm(MPInt n, int ipt[], int kp)
  {
    
    //  Returns the first prime divisor of the multiprecision N. Subroutine
    // PRIMES must have been previously called to initialize the array IPT.
    
    MPInt k;
    int i;
    
    //!     Check 3 separately (must be congruent to 2 mod 3).
    int id = 3;
    k = n.divide(new MPInt(id));
    int l = (new MPInt(n)).subtract(k.multiply(new MPInt(id))).intValue();
    if (l == 0) return id;
    if (l == 1) return -3;
    
    for (i = 1; i < kp; i++) 
    {
      MPInt mpId = new MPInt(ipt[i-1]);
      k = n.divide(mpId);
      l = n.subtract(k.multiply(mpId)).intValue();
      if (l == 0) return mpId.intValue();
    }
    return 0;
  }
  
  static MPInt ranprm(int ipt[], int kp, int nd4)
  {
    
    //!     Finds a large prime number.  Subroutine PRIMES must have
    //been previously 
    //!     called to initialize the array IP and determine KP.
    
    MPInt iq, ix, iy, iz, k, n, n1;
    MPReal id;
    final int it = 10;
    int ii, jj, ik;
    
    int nt = 20*nd4;
    id = new MPReal((new MPInt(10)).pow(nd4).divide(TWO));
    
    for (int j = 1; j <= nt; j++) 
    { 
      //!     Generate a trial prime N that is odd.
      //      n1 = 2*MPInt(id*mp_rand());
      n1 = new MPInt(id.multiply(MPReal.rand()));
      n1 = n1.multiply(TWO);
      n = n1.add(ONE);
      
      //!     Perform quick-and-dirty check for primality.
      int kd = idivm(n, ipt, kp);
      if (kd != 0) continue;
      
      //!     Quick test failed to find any divisors.  Proceed with
      //      advanced test.
      iq = n1;
      
      for (ik = 0; ik <= 30; ik++) 
      {
        k = iq.divide(TWO);
        if (iq.compareTo(k.multiply(TWO)) != 0) break;
        iq = k;
      }
      //!     Now N = 1 + Q * 2^IK, where Q is odd.
      
 outerloop: for (ii = 1; ii <= it; ii++) 
      {
        ix = new MPInt(new MPReal(n).multiply(MPReal.rand()));
        iy = ONE;
        iz = ix;	  
        while(true)
        {
          k = iq.divide(TWO);
          if (iq.compareTo(k.multiply(TWO)) != 0) iy = iz.multiply(iy).mod(n);
          iq = k;
          if(iq.compareTo(ZERO) == 0)
            break;
          iz = iz.multiply(iz).mod(n);
        }
        
        
        //!     Now Y = X^Q (mod N).
        jj = 0;
        if (iy.compareTo(ONE) == 0) continue;
        
        //!     Check primality conditions.
        while(true)
        {
          jj++;
          if (jj > ik) {break outerloop;}
          if (iy.compareTo(n1)==0) break;
          if (iy.compareTo(ONE)==0) {break outerloop;}
          iy = iy.multiply(iy).mod(n);
        }
      }
      
      //!     N is probably prime.
      
      if(ii<=it) // has broken from outerloop?
        continue;
      
       return n;
      
      
      //!     N is definitely not prime.
      
    }
    
    throw new ArithmeticException("Failed to find a prime.  No. trials = " +  nt); // here
  }
  
  
  static final int ID[] = {1, 7, 11, 13, 17, 19, 23, 29};
   
  static int idiv(int n)
  {
    //!     Returns the first prime divisor of N (single precision).
    
    int kd, i, k, l, m;
    
    if (n%3 == 0) 
      return 3;
    
    if (n%5 == 0) 
      return 5;
    
    kd = 0;
    if (n == 29) return kd;
    k = 2;
    l = 0;
    m = (int)(Math.sqrt(n));
    
    while (true)
    {
      for (i = k-1; i < 8; i++) 
      {
        kd = ID[i] + l;
        if (n%kd == 0) return kd;
      }
      
      kd = 0;
      l += 30;
      if (l > m) return kd;
      k = 1;
    }
  }
  
  
  static final int IPI[] = {3, 5, 7, 11, 13, 17, 19, 23, 29};
   
  static void primes(int ipt[], int kp)
  {
    
    //!     Places the first KP prime numbers in IPT.
    
    int i;
    System.arraycopy(IPI, 0, ipt,0,9);
    //for(i=0;i<9;i++)
    //  ipt[i]=IPI[i];

    int k = 9;
    
    for (i = 31; i <= 1000000; i += 2) 
    {
      if (idiv(i) == 0) 
      {
        ipt[k] = i;
        k++;
        if (k == kp) return;
      }
    }
    
    //cout << "Table IPT not filled: " << k<< '\n';
    System.exit(-1);
  }
  
  
  static MPInt expm(final MPInt ia, final MPInt ib, final MPInt ic)  
  {
    //!     Computes        IP = IA ** IB (mod IC)  for integers IA, IB, IC.
    
    MPInt ip,k, l, l2;
    
    k = ia;
    l = ib;
    ip = ONE;
    int j = 0;
    
    
    //!     Perform binary algorithm for exponentiation modulo IC.
    do
    {
      j++;
      l2 = l.divide(TWO);
      if (l.compareTo(l2.multiply(TWO)) != 0) ip = k.multiply(ip).mod(ic);
      k = k.multiply(k).mod(ic);
      l = l2;
    }
    while (l.compareTo(ZERO) != 0);
    return ip;
  }
  
  
  public static void main(String args[])
  {
    if(args.length != 2)
    {
       System.out.println("usage: run Rsa <precision> <number-of-iteration>");
       System.exit(1);
    }

    MPReal.setMaximumPrecision(new MPPrecision(Integer.parseInt(args[0])));
    int ij, limit = Integer.parseInt(args[1]);
    Timer time = new Timer();
    time.start();
    for(ij=0;ij<limit;ij++)
    {
    MPInt  ia = new MPInt(), ib, id = new MPInt(), ie = new MPInt(), 
      ip, iq, ix, iy, iz;
    final int n1 = 10, n2 = 10, kp = 200;
    int ipt[] = new int[kp];
    
    //!  Initialize.
    int nd = MPInt.getMpipl()-15;
    int nd4 = nd/4;
    primes(ipt, kp);
    
    //!     Begin outer loop.
    for (int k = 1; k <= n2; k++) 
    {

      
      //!     Step 1:  obtain two large primes, each congruent to 2
      //mod 3, with a size
      //!     somewhat less than half the machine precision level.
      ip = ranprm(ipt, kp, nd4);
      
      do
      {
        iq = ranprm(ipt, kp, nd4);
      }
      while (ip.compareTo(iq) == 0);
      
      //!    Step 2:  Compute        A = P * Q  and  B = (P-1) * (Q-1).
      ia = ip.multiply(iq);
      ib = ip.subtract(ONE).multiply(iq.subtract(ONE));
      
      //!    Step 3:  Set E = 3 and compute D = E inv (mod B)        = B -
      //[B/3]
      ie = THREE;
      id = ib.subtract(ib.divide(THREE));
    }
    
    //!    Step 4: Encrypt and decrypt a series of numbers chosen
    //at random.
    for (int j = 1; j <= n1; j++) 
    {
      ix = new MPInt((new MPReal(ia)).multiply(MPReal.rand()));
      iy = expm(ix, ie, ia);
      iz = expm(iy, id, ia);
      if (ix.compareTo(iz) != 0) 
      {
        System.out.print("*** Test failed. "  + j + "\nx = "
           + ix + "y = " + iy + "z = " + iz);
        System.exit(1);
      }
    }
    }
    time.stop();
    time.report(limit);

  }
  
  
}





