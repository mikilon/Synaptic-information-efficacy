#!/usr/local/bin/perl

# This script runs each line of file $CONFIGFILENAME and prints the output in file $REPORTFILENAME.
# To add/change commands, edit $CONFIGFILENAME.
# Written by Herman Harjono      11/3/1998

$CONFIGFILENAME = "config";
$REPORTFILENAME = "report";

# check whether report file exist and make backup if it does.
if (-e $REPORTFILENAME)
{
    rename $REPORTFILENAME, "$REPORTFILENAME.bak";
}

# make STDOUT unbuffered (see pg. 193 of Perl book)
select STDOUT; $| = 1;
open(IN, $CONFIGFILENAME);
while(<IN>)
{
    open(OUT, ">>$REPORTFILENAME");
    chop;
    if($_ eq "")
    {
	next;
    }
    print $_, "...\n";
    open PIPE, "$_|";
    print OUT $_, " ", <PIPE>;
    close PIPE;
    close OUT;
}

close(IN);



