import mpfun.*;
import timer.*;

/*
* Test program for MPPSLQ, a new version of Helaman Ferguson's PSLQ algorithm
* for detecting integer relations in a vector of real numbers.
* One-level Fortran-90 MP version.
*
* David H. Bailey     June 3, 1994
*
* Converted to Java by Herman Harjono
* October 28, 1998
*   
* These parameters are set in the PARAMETER statement below.  Some other
* parameters are set in other routines.
*  IDB = Debug level (0 -- 3).
*  ITR = Number of random trials when KQ = 1 or 2.
*  GAM = Gamma, the PSLQ algorithm parameter.  Typically set to either
*        Sqrt (4/3) = 1.154700538 or 4/3 = 1.333333333.
*  N   = Integer relation vector length.
*  KQ  = 0 for the algebraic case [1, AL, AL^2, ... AL^(N-1)], where
*        AL = 3^(1/KR) - 2^(1/KS).  Set N = KR * KS + 1 and ITR = 1.
*      = 1 for a random integer vector with a relation.
*      = 2 for a random integer vector without a relation.
*      = 3 for testing algebraic relations of a number read from a file.
*      = 4 for testing additive relations of numbers read from a file.
*      = 5 for testing multiplicative relations of numbers read from a file.
*      = 6 for custom input.
*  KR  = Degree of root of 3 when KQ = 0.
*  KS  = Degree of root of 2 when KQ = 0.
*  IDV = Number of digits in the random vector values (except the last)
*        when KQ = 1 or 2.
*  MR  = Log_10 of the max. random relation coefficients when KQ = 1 or 2.
*  MN  = Log_10 of the max. acceptable norm of relations.  If KQ = 1, set
*        MN = MR + 1.
*  RM  = Maximum size of random relation coefficients when KQ = 1 or 2
*        (may be set as 10^MR or to some other value).
*/
public final class Pslqm 
{
  static final MPReal ONE = new MPReal(1);
  static final MPReal TWO = new MPReal(2);
  static final MPReal THREE = new MPReal(3);
  static final MPReal TEN = new MPReal(10);
  static final MPReal ZERO = new MPReal();
  static final MPReal POINTFIVE = new MPReal(0.5);
  
  
  public static void main(String args[])
  {
    if(args.length != 2)
    {
       System.out.println("usage: run Pslqm <precision> <number-of-iteration>");
       System.exit(1);
    }

    MPReal.setMaximumPrecision(new MPPrecision(Integer.parseInt(args[0])));
    int ij, limit = Integer.parseInt(args[1]);
    Timer time = new Timer();
    time.start();
    for(ij=0;ij<limit;ij++)
    {
    final int idb = 0;
    final int itr = 1;
    final double gam = 1.154700538;
    final int n = 21, kq = 0;
    final int kr = 4;
    final int ks = 5;
    final int idv = 0;
    final int mr = 20;
    final int mn = mr+1;
    double rm = Math.pow(10, mr);
    MPReal r[] = new MPReal[n], x[] = new MPReal[n], al = new MPReal(), 
      t1 = new MPReal(), ti;
    double dr[] = new double[n], r1[] = new double[n];
    
    int ndp = MPReal.getMpipl();
    double tm = 0.0;
    int kps = 0;
    int kcs = 0;
    double d1;
    int i;
    
    for (int k = 1; k <= itr; k++) 
    {
      switch (kq) 
      {
      case 0:
        // This code generates AL = 3^(1/KR) - 2^(1/KS).  AL is algebraic of degree
        // KR * KS.  Use N = KR * KS + 1 to recover the polynomial satisfied by AL.
        
        al = THREE.nrtf(kr).subtract(TWO.nrtf(ks));
        break;
      case 1:
        // Construct a random input vector X with a relation.
        d1 = 2.0*rm+1.0;
        ti = TEN.pow(idv);
        t1 = ZERO;
        
        for (i = 1; i < n; i++) 
        {
          r1[i-1] = aint(d1*drand())-rm;
          x[i-1] = t1.multiply(MPReal.rand()).aint();
          t1 = (new MPReal(r1[i-1])).multiply(x[i-1]).add(t1);
        }
        
        r1[n-1] = ONE.sign(t1).negate().doubleValue();
        x[n-1] = t1.abs();
	
        break;
      case 2:
        ti = TEN.pow(idv);
        
        // Construct a random input vector X without a relation.
        
        for (i = 0; i < n; i++)
          x[i] = t1.multiply(MPReal.rand()).aint();
        break;
      case 3:
        // Read an algebraic constant from a file.
        /*  {
        ifstream from("pslq.inp");
        from >> al;
      }*/
        break;
      case 4:
        // Read constants from a file for additive test.
        /*{
        ifstream from("pslq.inp");
        for (i = 0; i < n; i++) 
        {
        from >> al;
        x[i] = al;
        }
      }*/
        break;
      case 5:
        // Read constants from a file for multiplicative test.
        /*
        {
        ifstream from("pslq.inp");
        for (i = 0; i < n; i++) {
        from >> al;
        x[i] = log(al);
        }
      }*/
        break;
      case 6:
        // Produce X vector by a custom scheme.
        break;
      }
      
      // If KQ is 0 or 3, generate X = [1, AL, AL^2, ..., AL^(N-1)].
      
      if (0 == kq || 3 == kq) 
      {
        x[1-1] = ONE;
        for (i = 2; i <= n; i++) 
        {
          x[i-1] = al.multiply(x[i-1-1]);
        }
      }
      
      // Perform relation search.
      
      int iq = 0;
      iq = mppslq(idb, gam, n, mn, x, r);
      
      // Check if original relation was recovered.
      
      if (iq != 0) 
      {     
        for (i = 1; i <= n; i++) 
        {
          if (r[i-1].abs().compareTo(new MPReal(1e15)) < 0)
            dr[i-1] = r[i-1].doubleValue();
          else
            dr[i-1] = (new MPReal(999999999999999.0)).sign(r[i-1]).doubleValue();
        }
        
	        
        if (kq >= 1) 
        {
          d1 = 0.0;
          double d2 = 0.0;
          
          for (i = 1; i <= n; i++) 
          {
            d1 += Math.abs(r[i-1].doubleValue() - r1[i-1]);
            d2 += Math.abs(r[i-1].doubleValue() + r1[i-1]);
          }
          
          if (Math.abs(d1) <= 1e-6 || Math.abs(d2) <= 1e-6) 
          {
            kcs++;
	  }
          else
            kps++;
        }
      }
}

if (itr > 1) 
{
  System.out.println("No. partial successes = " + kps
    + "\nNo. complete successes = " + kcs);
  int kss = kps+kcs;
  if (kss != 0)
  {
    tm /= kss;
    System.out.println("Ave. CPU Time of PS or CS runs = " + tm);
  }
}

    }
    time.stop();
    time.report(limit);
}

static double aint(double x)
{
  if (Math.abs(x) < 1.0) return 0.0;
  return Math.floor(Math.abs(x))*(x >= 0 ? 1.0 : -1.0);
}

static double anint(double a) {return a > 0 ? aint(a+0.5) : aint(a-0.5);}


/*
* The following parameters are set in this routine:
*   IPI = Iteration print interval when IDB = 2.
*   ITM = Maximum iteration count.  Run is aborted when this is exceeded.
*/
static int mppslq(final int idb, final double gam, final int n, final int
                  mn, MPReal x[], MPReal r[])
{
  int iq=0;
  final int ipi = 100;
  final int itm = 100000;
  MPReal a[][], b[][], h[][], ss[][], s[], w1[], w2[], y[], ty1, ty2;
  int i, j;
  double dm;
  
  a = new MPReal[n][n];
  b = new MPReal[n][n];
  h = new MPReal[n][n-1];
  ss = new MPReal[n][n];
  s = new MPReal[n];
  w1 = new MPReal[n];
  w2 = new MPReal[n];
  y = new MPReal[n];
  
  // Initialize.
  double tm2 = 0.0;
  iq = 0;
  int it = 0;
  double rn = 0.0;
  double rb = Math.pow(10.0, mn);
  initmp(idb, n, a, b, h, s, x, y);
  
  int izm=0;
  while(izm<=0)
  {
    it++;
    if (it > itm) 
    {
      
      return iq;
    }
    
    if (0 == it%ipi) 
    {
      // Compute norm bound.
      
      double d1 = bound(n, h);
      rn = Math.max(rn, d1);
      
      if (idb >= 2) 
      {
        ty1 = new MPReal(1e100);
        ty2 = ZERO;
        
        for (i = 0; i < n; i++) 
        {
          ty1 = ty1.min(y[i].abs());
          ty2 = ty2.max(y[i].abs());
        }
        
      }
      if (rn > rb) 
      {
        
        return iq;
      }
    }
    
    // Perform MP reductions.
    
    izm = itermp(idb, gam, it, n, a, b, h, y);
    if (-2 == izm)
    {
       return iq;  
    }
  }
  
  // A relation has been detected.  Output the final norm bound.
  if (idb >= 1) 
  {
    System.out.println("Relation detected.\n"
      + "No. iterations = " + it 
      + "\nMax. bound = " + rn);
  }
  dm = 1e100;
  
  // If there is more than one relation, select the one with smallest norm.
  double d1;
  for (j = 1; j <= n; j++) 
  {
    if (y[j-1].abs().compareTo(MPReal.mpeps) <= 0) 
    {
      d1 = 0.0;
      for (i = 1; i <= n; i++)
        d1 += Math.pow(b[i-1][j-1].doubleValue(), 2);
      d1 = Math.sqrt(d1);
      if (idb >= 1) 
      {
        System.out.println("Index of relation = " + j
          + "        Norm = " + d1);
      }
      if (idb >= 2) 
      {
        System.out.println("Residual = \n" + y[j-1]
          + "Relation:\n");
        //matout(1, n, b[1-1][j-1]);
        matout(1, n, j-1, b);
      }
      if (d1 < dm) 
      {
        dm = d1;
        for (i = 1; i <= n; i++)
          r[i-1] = b[i-1][j-1];
      }
    }
  }
  
  if (dm <= rb)
    iq = 1;
  else {
    if (idb >= 2) System.out.println("Relation is too large.");
  }
  
  return iq; 
}

/**
* Initializes MP arrays at the beginning.      
*/
static void initmp(final int idb, final int n, MPReal a[][], MPReal b[][],
                   MPReal h[][], MPReal s[], MPReal x[], MPReal y[])
                   
{
  int i,j, k;
  if (idb >= 2) 
  {
    System.out.println("Input X vector:");
    matout(1, n, x);
  }
  
  // Set A and B to the identity matrix.
  
  for (j = 0; j < n; j++) 
  {
    for (i = 0; i < n; i++) 
      a[i][j] = b[i][j] = ZERO;
    
    a[j][j] = b[j][j] = ONE;
  }
  
  MPReal t1 = ZERO;
  
  // Compute the S vector, the square root of the partial sum of squares of X,
  // and compute the Y vector, which is the normalized X vector.
  
  for (i = n; i >= 1; i--) 
  {
    t1 = t1.add(x[i-1].pow(2));
    s[i-1] = t1.sqrt();
  }
  
  t1 = ONE.divide(s[1-1]);
  
  for (i = 0; i < n; i++) 
  {
    y[i] = t1.multiply(x[i]);
    s[i] = s[i].multiply(t1);
  }
  
  // Compute the initial H matrix.
  
  for (i = 1; i <= n; i++) 
  {
    for (j = i+1; j <= n-1; j++)
      h[i-1][j-1] = ZERO;
    
    if (i <= n-1)
      h[i-1][i-1] = s[i+1-1].divide(s[i-1]);
    
    for (j = 1; j <= i-1; j++)
      h[i-1][j-1] = y[i-1].negate().multiply(y[j-1]).divide(s[j-1].multiply(s[j+1-1]));
  }
  
  // Perform full reduction on H, updating A and B.
  
  MPReal tm;
  for (i = 2; i <= n; i++) 
  {
    for (j = i-1; j >= 1; j--) 
    {
      if (h[i-1][j-1].abs().compareTo(POINTFIVE.multiply(h[j-1][j-1].abs())) > 0)
      {
        tm = h[i-1][j-1].divide(h[j-1][j-1]).anint();
        y[j-1] = y[j-1].add(tm.multiply(y[i-1]));
        
        for (k = 1; k <= j; k++)
          h[i-1][k-1] = h[i-1][k-1].subtract(tm.multiply(h[j-1][k-1]));
        
        for (k = 1; k <= n; k++) 
        {
          a[i-1][k-1] = a[i-1][k-1].subtract(tm.multiply(a[j-1][k-1]));
          b[k-1][j-1] = b[k-1][j-1].add(tm.multiply(b[k-1][i-1]));
        }
      }
    }
  }
  
  
  if (idb >= 3) 
  {
    System.out.println("Initial H:");
    matout(n, n-1, h);
    System.out.println("Initial A matrix");
    matout(n, n, a);
    System.out.println("Initial B matrix");
    matout(n, n, b);
    System.out.println("Initial Y:");
    matout(1, n, y);
  }
}

/**
*   This performs one iteration of the PSLQ algorithm using MP arithmetic.
*/          
static int itermp(final int idb, final double gam, final int it, final int
                  n, MPReal a[][], MPReal b[][], MPReal h[][], MPReal y[])                        
{
  int izm;
  int i,j,k;
  if (idb >= 3)
    System.out.println("Iteration " + it + "   MP iteration");
  MPReal tl1 = ONE.divide(MPReal.mpeps);
  
  // Select IM = I such that GAM^I * |H(I,I)| is maximal.
  
  izm = 0;
  MPReal t1 = ZERO, t2, t3, t4;
  int im=0;
  
  for (i = 1; i < n; i++) 
  {
    t2 = (new MPReal(Math.pow(gam, i))).multiply(h[i-1][i-1].abs());
    if (t2.compareTo(t1) > 0) 
    {
      im = i;
      t1 = t2;
    }
  }
  
  if (idb >= 3) System.out.println("IM = " + im);
  int im1 = im+1;
  
  // Perform block reduction on H, updating A and B.
  MPReal tm;
  for (i = im1; i <= n; i++) 
  {
    int jl = Math.min(i-1, im1);
    
    for (j = jl; j >= 1; j--) 
    {
      if (h[i-1][j-1].abs().compareTo(POINTFIVE.multiply(h[j-1][j-1].abs())) > 0) 
      {
        tm = h[i-1][j-1].divide(h[j-1][j-1]).anint();
        y[j-1] = tm.multiply(y[i-1]).add(y[j-1]);
        
        for (k = 1; k <= j; k++)
          h[i-1][k-1] = h[i-1][k-1].subtract(tm.multiply(h[j-1][k-1]));
        
        for (k = 1; k <= n; k++) 
        {
          a[i-1][k-1] = a[i-1][k-1].subtract(tm.multiply(a[j-1][k-1]));
          b[k-1][j-1] = tm.multiply(b[k-1][i-1]).add(b[k-1][j-1]);
        }
      }
    }
  }
  
  // Find the max of the updated A and the Math.min of Y.
  
  MPReal ta = ZERO;
  MPReal ty = new MPReal(1e100);
  
  for (j = 1; j <= im1; j++) 
  {
    ty = ty.min(y[j-1].abs());
    
    for (i = im1; i <= n; i++)
      ta = ta.max(a[i-1][j-1].abs());
  }
  
  if (ta.compareTo(tl1) > 0) 
  {
    if (idb >= 1) 
    {
      System.out.println("Iteration " + it +
        "\nITERMP: Large entry in A:\n" + 
        ta + "Run aborted.");
    }
    return -2;
  }
  
  if (h[n-1-1][n-1-1].abs().compareTo(MPReal.mpeps) <=0) 
  {
    if (idb >= 2) 
    {
      System.out.println("Iteration " + it 
        + "\nITERMP: Small value in H:\n"
        + h[n-1-1][n-1-1]);
    }
    izm = 1;
  }
  
  if (ty.compareTo(MPReal.mpeps) <=0) 
  {
    if (idb >= 2) 
    {
      System.out.println( "Iteration " + it 
        + "\nITERMP: Small value in Y:\n"
        + ty);
    }
    izm = 1;
  }
  
  // Exchange the IM and IM+1 rows of A, the columns of B and the rows
  // of H.
  
  t1 = y[im-1];
  y[im-1] = y[im1-1];
  y[im1-1] = t1;
  
  for (i = 1; i <= n; i++) 
  {
    t1 = a[im-1][i-1];
    a[im-1][i-1] = a[im1-1][i-1];
    a[im1-1][i-1] = t1;
    t1 = b[i-1][im-1];
    b[i-1][im-1] = b[i-1][im1-1];
    b[i-1][im1-1] = t1;
  }
  
  for (i = 1; i < n; i++) 
  {
    t1 = h[im-1][i-1];
    h[im-1][i-1] = h[im1-1][i-1];
    h[im1-1][i-1] = t1;
  }
  
  // Update H with permutation produced above.
  
  if (im <= n-2) 
  {
    t1 = h[im-1][im-1];
    t2 = h[im-1][im1-1];
    t3 = t1.pow(2).add(t2.pow(2)).sqrt();
    t1 = t1.divide(t3);
    t2  = t2.divide(t3);
    
    for (i = im; i <= n; i++) 
    {
      t3 = h[i-1][im-1];
      t4 = h[i-1][im1-1];
      h[i-1][im-1] = t1.multiply(t3).add(t2.multiply(t4));
      h[i-1][im1-1] = t2.negate().multiply(t3).add(t1.multiply(t4));
    }
  }
  
  if (idb >= 3) 
  {
    System.out.println("Updated A matrix:");
    matout(n, n, a);
    System.out.println("Updated B matrix:");
    matout(n, n, b);
    System.out.println("Updated H matrix:");
    matout(n, n-1, h);
    System.out.println("Updated Y:");
    matout(1, n, y);
  }
  
  return izm;
}

/**
* This computes the norm bound.
*/
static double bound(final int n, MPReal h[][])
{
  double t1 = 0.0;
  
  for (int i = 1; i <= n; i++) 
  {
    double t2 = 0.0;
    for (int j = 1; j < n; j++) 
    {
      t2 += Math.pow(h[i-1][j-1].doubleValue(), 2);
    }
    t1 = Math.max(t1, t2);
  }
  return 1.0/Math.sqrt(t1);
}

/**
* This outputs the MP matrix A.
*/
static void matout(final int n1, final int n2, MPReal a[][])
{
  for (int i = 1; i <= n1; i++) {
    System.out.println("Row " + i);
    for (int j = 1; j <= n2; j++)
      System.out.print(a[i-1][j-1]);
  }
}

/**
* This outputs column c of the MP matrix A.
*/
static void matout(final int n1, final int n2, final int c, MPReal a[][])
{
  for (int i = 1; i <= n1; i++) 
  {
    System.out.println("Row " + i);
    System.out.print(a[i-1][c]);
  }
}


/**
* This outputs the MP matrix A.
*/
static void matout(final int n1, final int n2, MPReal a[])
{
  for (int i = 1; i <= n1; i++) 
  {
    System.out.println("Row " + i);
    for (int j = 1; j <= n2; j++)
      System.out.print( (1 == n1 ? a[j-1] : a[i-1]));
  }
}


/*
* This routine returns a pseudorandom DP floating number nearly uniformly
* distributed between 0 and 1 by means of a linear congruential scheme.
* 2^28 pseudorandom numbers with 30 bits each are returned before repeating.
*/
static double drand()
{
  final double f7 = 78125.0;
  double r30 = Math.pow(0.5, 30);
  double t30 = Math.pow(2, 30);
  
  double t1 = f7*sd;
  double t2 = aint(r30*t1);
  sd = t1-t30*t2;
  return r30*sd;
}
static double sd = 314159265.0;



}

