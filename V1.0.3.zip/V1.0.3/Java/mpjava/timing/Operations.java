import mpfun.*;
import timer.*;

public final class Operations
{
   public static void main(String args[])
   {
      if(args.length<1)
      {
	 System.out.println("Usage: run Operations <precision-1> <precision-2> ...");
	 return;
      }
      int i;
      for(i=0;i<args.length;i++)
	 doIt(Integer.parseInt(args[i]));
   }

   public static void doIt(int precision)
   {
      System.out.println("Precision: " + precision);
      Timer time = new Timer();
      MPReal.setMaximumPrecision(new MPPrecision(precision));
      MPReal a = MPReal.rand();
      MPReal b = MPReal.rand();

      int i, iteration;

      // testing addition
      iteration = 1; time.reset();
      while(time.isLessThanTwoSeconds())
      {
	 time.start();
	 for(i=0;i<iteration; i++)
	    a.add(b);
	 time.stop();
	 iteration *= 4;
      }
      report("Addition", time, iteration);

      // testing subtraction
      iteration = 1; time.reset();
      while(time.isLessThanTwoSeconds())
      {
	 time.start();
	 for(i=0;i<iteration; i++)
	    a.subtract(b);
	 time.stop();
	 iteration *= 4;
      }
      report("Subtraction", time, iteration);

      // testing Multiplication
      iteration = 1; time.reset();
      while(time.isLessThanTwoSeconds())
      {
	 time.start();
	 for(i=0;i<iteration; i++)
	    a.multiply(b);
	 time.stop();
	 iteration *= 4;
      }
      report("Multiplication", time, iteration);

      // testing Division
      iteration = 1; time.reset();
      while(time.isLessThanTwoSeconds())
      {
	 time.start();
	 for(i=0;i<iteration; i++)
	    a.divide(b);
	 time.stop();
	 iteration *= 4;
      }
      report("Divide", time, iteration);

      // testing Square Root
      iteration = 1; time.reset();
      while(time.isLessThanTwoSeconds())
      {
	 time.start();
	 for(i=0;i<iteration; i++)
	    a.sqrt();
	 time.stop();
	 iteration *= 4;
      }
      report("Square Root", time, iteration);

      // testing Sine
      iteration = 1; time.reset();
      while(time.isLessThanTwoSeconds())
      {
	 time.start();
	 for(i=0;i<iteration; i++)
	    a.sin();
	 time.stop();
	 iteration *= 4;
      }
      report("Sine", time, iteration);

       // testing Hyperbolic Sine
      iteration = 1; time.reset();
      while(time.isLessThanTwoSeconds())
      {
	 time.start();
	 for(i=0;i<iteration; i++)
	    a.sinh();
	 time.stop();
	 iteration *= 4;
      }
      report("Sinh", time, iteration);
      
   }  

   private static void report(String op, Timer t, int iteration)
   {
      System.out.print(op + " takes ");
      t.milliReport(iteration);

   }

    

}
