import java.util.*;
/**
 * @author shmulik
 */
public class TestSpikeTrainReader {

    public static void main(String[] args)  {
	try { 
	    float[] sptf;
	    Vector spt = new Vector();
	    String filename = args[0];
	    SpikeTrainReader reader = new SpikeTrainReader(filename);
	    while (reader.hasMoreElements()) {
		float index = reader.readNextFloat();
		spt.addElement(new Float(index));
		System.out.println(index);
	    }
	
	    SpikeTrainBinner Binner = new SpikeTrainBinner();
	    Binner.binsize(3);
	    sptf = new float[spt.size()];
	    sptf = vec2FloatArray(spt);
	    String sptb = Binner.binIt(sptf,0,50);
	    System.out.println(sptb);
	    FileListReader flr = new FileListReader("list.txt");
	    String fn;
	    while ( (fn = flr.readNextString() ) != null) { 
		System.out.println(fn+"=");
	    } 
		
	} catch (Exception e) {
	    e.printStackTrace();
	}
	
    }
    

    public static float[] vec2FloatArray(Vector v){
	float[] a = new float[v.size()];
	int count=0;
	Enumeration e = v.elements();
	while( e.hasMoreElements() ){
	    Float wrapper = (Float) e.nextElement();
	    a[ count ] = wrapper.floatValue();
	    count += 1;
	}
	return a;
    }
    
}
