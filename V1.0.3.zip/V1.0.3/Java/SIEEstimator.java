import mpfun.*;
import java.io.*;
import java.util.*;
import java.lang.*;

/**
 * SIEEstimator  reads several parameters from the args and estimates SIE in bits/s from one or more SIE experimental traces.
 * The format is SIEEstimator D, start, duration, binsize, shiftinput, SIEtrace1, SIEtrace2, .....
 * where shiftinput is a time shift for the input sequence (wither negative or positive).
 * The program read the first arguments and then loop through the traces. computing one tree for the output 
 * and one tree for the input.
 * Currently, we need to build the two trees in sequence because there is a problem with the CTWconst.alphabet.
 * We should modify it so we can run two trees of different alphabet in the same time. 
 *
 * <Br>
 * @author Mickey London (m.london@ucl.co.uk, mikilon@gmail.com) 
 */


public final class SIEEstimator
{
    private static ArrayList allsources = new ArrayList();
    private static ArrayList allHestimates = new ArrayList();
    private static ArrayList allRHestimates = new ArrayList();

    static float  start;
    static float  duration;
    static float  binsize;
    static float  shiftinput;
    public static void main(String args[]) throws java.io.IOException
    {    
	int nextsym = -1;
	SourceSequence sourceX;
	SourceSequence sourceXY;
	String sptinfn,sptoutfn;
	CTWEntropyEstimator estimator;
	CTWConditionalEntropyEstimator cestimator;
	Float Hval,RHval,RHvalControl;
	float Hbitspersec,RHbitspersec,RHbitspersecControl,SIEbitspersec,SIEbitspersecControl,SIEbitspersecCorrected;
								   
	readParams(args);
        // Estimate the output entropy
	sptoutfn = new String("sptout_SIE"+args[5]);
	sourceX = new SourceSequence(sptoutfn,start,duration,binsize);    
	estimator = new CTWEntropyEstimator(sourceX,CTWConst.D,CTWConst.D+1,sourceX.length()-CTWConst.D-1);   
	if (args.length > 5) { 
	    for (int i=6;i<args.length;i++) {
		sptoutfn = new String("sptout_SIE"+args[i]);
	    	sourceX = new SourceSequence(sptoutfn,start,duration,binsize);    
		estimator.updateCTWEntropyEstimator(sourceX,CTWConst.D+1,sourceX.length()-CTWConst.D-1);   
	    }
	    allHestimates.add(new Float(estimator.estimate().floatValue()));
	}
	Hval = (Float) allHestimates.get(allHestimates.size()-1);
	Hbitspersec = Hval.floatValue()/((float)binsize)*((float) 1000); 
	//	System.out.println(Hbitspersec);
	//	saveEstimates(args[5],CTWConst.D,Float.parseFloat(args[3]));

	// -- computing conditional entropy
	sptoutfn = new String("sptout_SIE"+args[5]);
	sptinfn = new String("sptin_SIE"+args[5]);
	sourceX = new SourceSequence(sptoutfn,start,duration,binsize);   
	// 	sourceXY = new SourceSequence(sptinfn,sptoutfn,start,duration,binsize);   
 	sourceXY = new SourceSequence(sptinfn,sptoutfn,start,duration,binsize,shiftinput);   

	cestimator = new CTWConditionalEntropyEstimator(sourceX,sourceXY,CTWConst.D,CTWConst.D+1,sourceX.length()-CTWConst.D-1);   
	if (args.length > 5) { 
	    for (int i=6;i<args.length;i++) {
	    	sptoutfn = new String("sptout_SIE"+args[i]);
		sptinfn = new String("sptin_SIE"+args[i]);
		sourceX = new SourceSequence(sptoutfn,start,duration,binsize);   
		//		sourceXY = new SourceSequence(sptinfn,sptoutfn,start,duration,binsize);   
	 	sourceXY = new SourceSequence(sptinfn,sptoutfn,start,duration,binsize,shiftinput);   
		cestimator.updateCTWConditionalEntropyEstimator(sourceX,sourceXY,CTWConst.D+1,sourceX.length()-CTWConst.D-1);   
	    }
	    allRHestimates.add(new Float(cestimator.estimate().floatValue()));
	}
	RHval = (Float) allRHestimates.get(allRHestimates.size()-1);
	RHbitspersec = RHval.floatValue()/((float)binsize)*((float) 1000); 
	//System.out.println(RHbitspersec);
	//	saveEstimates(args[5],CTWConst.D,Float.parseFloat(args[3]));
	
	SIEbitspersec = Hbitspersec-RHbitspersec; 
	
	// -- computing conditional entropy with shuffled input
	sptoutfn = new String("sptout_SIE"+args[5]);
	sptinfn = new String("sptin_SIE"+args[5]);
	sourceX = new SourceSequence(sptoutfn,start,duration,binsize);   
 	sourceXY = new SourceSequence(sptinfn,sptoutfn,start,duration,binsize,shiftinput);   
    sourceXY.shuffle(sptinfn,sptoutfn,start,duration,binsize);  // shuffles the input spiketrain and recreate the 
															    // source   
	cestimator = new CTWConditionalEntropyEstimator(sourceX,sourceXY,CTWConst.D,CTWConst.D+1,sourceX.length()-CTWConst.D-1);   
	if (args.length > 5) { 
	    for (int i=6;i<args.length;i++) {
	    	sptoutfn = new String("sptout_SIE"+args[i]);
		sptinfn = new String("sptin_SIE"+args[i]);
		sourceX = new SourceSequence(sptoutfn,start,duration,binsize);   
		//		sourceXY = new SourceSequence(sptinfn,sptoutfn,start,duration,binsize);   
	 	sourceXY = new SourceSequence(sptinfn,sptoutfn,start,duration,binsize,shiftinput); 
		sourceXY.shuffle(sptinfn,sptoutfn,start,duration,binsize);  
		cestimator.updateCTWConditionalEntropyEstimator(sourceX,sourceXY,CTWConst.D+1,sourceX.length()-CTWConst.D-1);   
	    }
	    allRHestimates.add(new Float(cestimator.estimate().floatValue()));
	}
	RHvalControl = (Float) allRHestimates.get(allRHestimates.size()-1);
	RHbitspersecControl = RHvalControl.floatValue()/((float)binsize)*((float) 1000); 
	//System.out.println(RHbitspersec);
	//	saveEstimates(args[5],CTWConst.D,Float.parseFloat(args[3]));
	
	SIEbitspersec = Hbitspersec-RHbitspersec; 

	SIEbitspersecControl = Hbitspersec-RHbitspersecControl;
	SIEbitspersecCorrected = SIEbitspersec-SIEbitspersecControl;
	
	System.out.println(Hbitspersec+" " + RHbitspersec  + " " + SIEbitspersec + " " + RHbitspersecControl + " " + SIEbitspersecControl + " " + SIEbitspersecCorrected);
    }







    private static void readParams(String args[]) throws java.io.IOException 
    { 
	CTWConst.D = Integer.parseInt(args[0]);
	start = Float.parseFloat(args[1]);
	duration = Float.parseFloat(args[2]);
	binsize = Float.parseFloat(args[3]);
	shiftinput = Float.parseFloat(args[4]);
    }

    
    private static void saveEstimates(String  fname, int D, float bin) throws java.io.IOException { 
	Float val,val1;
	File out = new File(fname+".NoiseH_"+D+"_" +bin);   //h est with dynamic ctw
	FileWriter fw = new FileWriter ( out ); 
	PrintWriter pw = new PrintWriter( fw, true ); 
	ListIterator li = allHestimates.listIterator();
	ListIterator li1 = allRHestimates.listIterator();
	while (li.hasNext() ) { 
	    val = (Float) li.next();
	    val1 = (Float) li1.next();
	    pw.println(val.floatValue()+"\t"+val1.floatValue()); 
	}
	fw.close();
    }

}






















