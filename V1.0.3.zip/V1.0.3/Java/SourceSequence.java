import java.io.*;
import java.lang.*;
import java.util.*;

/**
 * Source sequence is a long string of symbols of a given alphabet 
 * There are some ways to instantiate using a file name, list of spike times or giving the 
 * source sequence itself.
 * @author Mickey
 */

public class SourceSequence extends Object {

    private String sourceseq;   // The source sequence, or the interleaved sequence when estimating MI
    private int pointer = 0;  
    private Vector sptin,sptout;    
	private Random generator = new Random();
    
    /** 
		* Reads the sequence from the file into sourceseq
		*/
    public SourceSequence(String ifname) throws IOException { 
		FileRead01(ifname);
    }
	
    /** 
		* Reads the sequence from two files and then interleave them into sourceseq
		* Like if file 1 (X) is "001001" and file 2 (Y) is "010101" then the source seq will be
		* yxyxyxyx ... -> 00 10 01 10 00 11
		*/
    public SourceSequence(String ifname1,String ifname2) throws IOException { 
		FileRead01(ifname1,ifname2);
    }
	
	
	/** 
		* Take a series of spike times and 
		* generates the source sequence from start with length duration using specified bin-size 
		* 
		*/
    public SourceSequence(float[] spiketrain,float start, float duration,float binsize) throws IOException { 
		int i;
		float[] sptin = spiketrain;
		SpikeTrainBinner binner = new SpikeTrainBinner();
		binner.binsize(binsize);
		sourceseq = binner.binIt(sptin,start,duration);
        //i = Math.min(sourceseq.length()/2,20);
        //System.out.println("Source:"+sourceseq.substring(0,i)+"..."+sourceseq.substring(sourceseq.length()-i,sourceseq.length()));  
    }
	
    // This reads two files and combine them into one source with dual alphabet. 
    public SourceSequence(float[] spiketrain1,float[] spiketrain2, float start, float duration,float binsize) 
		throws IOException { 
			int i;
			String sptin01,sptout01;
			float[] sptin = spiketrain1;
			float[] sptout = spiketrain2;
			
			SpikeTrainBinner binner = new SpikeTrainBinner();
			binner.binsize(binsize);
			sptin01  = binner.binIt(sptin,start,duration);
			sptout01 = binner.binIt(sptout,start,duration);
			combineXY(sptin01,sptout01);
		}
	// This reads two files and combine them into one source with dual alphabet. 
    public SourceSequence(float[] spiketrain1,float[] spiketrain2, float start, float duration,float binsize,float shiftinput) 
		throws IOException { 
			int i;
			String sptin01,sptout01;
			float[] sptin = spiketrain1;
			float[] sptout = spiketrain2;
			shiftInput(sptin,shiftinput);
			SpikeTrainBinner binner = new SpikeTrainBinner();
			binner.binsize(binsize);
			sptin01  = binner.binIt(sptin,start,duration);
			sptout01 = binner.binIt(sptout,start,duration);
			combineXY(sptin01,sptout01);
		}
	
	
	/** 
		* Reads the sequence as a series of spike times from the file named ifname and 
		* generates the source sequence from start with length duration using specified bin-size 
		* 
		*/
    public SourceSequence(String ifname,float start, float duration,float binsize) throws IOException { 
		int i;
		SpikeTrainReader spread = new SpikeTrainReader(ifname);
		float[] sptin = spread.readSpikeTrain();
		// System.out.println("sptin" + sptin.length);
		SpikeTrainBinner binner = new SpikeTrainBinner();
		binner.binsize(binsize);
		sourceseq = binner.binIt(sptin,start,duration);
        i = Math.min(sourceseq.length()/2,20);
        //System.out.println("Source:"+sourceseq.substring(0,i)+"..."+sourceseq.substring(sourceseq.length()-i,sourceseq.length()));  
    }
	
    // This reads two files and combine them into one source with dual alphabet. 
    public SourceSequence(String ifname1,String ifname2,float start, float duration,float binsize) 
		throws IOException { 
			int i;
			String sptin01,sptout01;
			SpikeTrainReader spread = new SpikeTrainReader(ifname1);
			float[] sptin = spread.readSpikeTrain();
			
			SpikeTrainBinner binner = new SpikeTrainBinner();
			binner.binsize(binsize);
			sptin01 = binner.binIt(sptin,start,duration);
			spread = new SpikeTrainReader(ifname2);
			float[] sptout = spread.readSpikeTrain();
			
			binner = new SpikeTrainBinner();
			binner.binsize(binsize);
			sptout01 = binner.binIt(sptout,start,duration);
			combineXY(sptin01,sptout01);
		}
	

    // Identical to the version with 5 args, but also apply a shift to the second sequence.
    public SourceSequence(String ifname1,String ifname2,float start, float duration,float binsize, float shiftinput) throws IOException { 
		int i;
		String sptin01,sptout01;
		SpikeTrainReader spread = new SpikeTrainReader(ifname1);
		
		float[] sptin = spread.readSpikeTrain();
		System.out.println("sptin[0]:" +  sptin[0]);
		shiftInput(sptin,shiftinput);
		System.out.println("after shift sptin[0]:" +  sptin[0]);
		SpikeTrainBinner binner = new SpikeTrainBinner();
		binner.binsize(binsize);
		sptin01 = binner.binIt(sptin,start,duration);
		spread = new SpikeTrainReader(ifname2);
		float[] sptout = spread.readSpikeTrain();
		
		binner = new SpikeTrainBinner();
		binner.binsize(binsize);
		sptout01 = binner.binIt(sptout,start,duration);
		combineXY(sptin01,sptout01);
	}
    
     public void shuffle(String ifname1,String ifname2,float start, float duration,float binsize) throws IOException { 
		int i;
		String sptin01,sptout01;
		SpikeTrainReader spread = new SpikeTrainReader(ifname1);
		
		float[] sptin = spread.readSpikeTrain();
		System.out.println("sptin[0]:" +  sptin[0]);
		shuffleInput(sptin);
		System.out.println("after shuffle sptin[0]:" +  sptin[0]);
		SpikeTrainBinner binner = new SpikeTrainBinner();
		binner.binsize(binsize);
		sptin01 = binner.binIt(sptin,start,duration);
		spread = new SpikeTrainReader(ifname2);
		float[] sptout = spread.readSpikeTrain();
		
		binner = new SpikeTrainBinner();
		binner.binsize(binsize);
		sptout01 = binner.binIt(sptout,start,duration);
        combineXY(sptin01,sptout01);
    }
	
	private void shiftInput(float[] sptin,float shiftinput) { 
		for (int i =0;i<sptin.length;i++) { 
			sptin[i] += shiftinput;
		}
    }
	
	private void shuffleInput(float[] sptin) {
	
		float[] isi = new float[sptin.length];
//	    printarr(sptin);
		for (int i =1;i<sptin.length;i++) { 
			isi[i] = sptin[i] - sptin[i-1];
		}
		sptin[0] = isi[generator.nextInt(isi.length)];
		for (int i =1;i<sptin.length;i++) { 
			sptin[i] = sptin[i-1] + isi[generator.nextInt( isi.length )];
		}
//		System.out.println("----------------\n");
//		printarr(sptin);
    }
	
    private void printarr(float[] v) { 
		for (int i =1;i<v.length;i++) { 
			System.out.println(v[i]);
		}
		
	}
	
	
	
	

    /**
     * Reads an 01001 like file 
     **/
    public  void  FileRead01(String ifname) throws IOException{
	int i;

        BufferedReader infile = new BufferedReader(new FileReader(ifname));
	sourceseq = infile.readLine();
        infile.close();
        i = Math.min(sourceseq.length()/2,20);
        //System.out.println("Source:"+sourceseq.substring(0,i)+"..."+sourceseq.substring(sourceseq.length()-i,sourceseq.length()));  
    }

    /**
     * Reads two 01001 like files X,Y and interleve them to a single sequence
     **/
    public  void  FileRead01(String ifname1,String ifname2 ) throws IOException{
	int i,l;
        String tmpx,tmpy;
	// Reading X
        BufferedReader infile = new BufferedReader(new FileReader(ifname1));
	tmpx = infile.readLine();
        infile.close();
	// Reading Y
        infile = new BufferedReader(new FileReader(ifname2));
	tmpy = infile.readLine();
        infile.close();
        combineXY(tmpx,tmpy);
    }


    /**
     * Reads two 01001 like files X,Y and interleve them to a single sequence
     **/
    public  void  combineXY(String X,String Y ) throws IOException{
	int i,l;
        char[] x,y,z;

    //    i = Math.min(X.length()/2,60);
	//        System.out.println("X:"+tmps.substring(0,i)+"..."+tmps.substring(tmps.length()-i,tmps.length()));  
        //System.out.println("X:"+X.substring(0,i));
        x = X.toCharArray();

	// Reading Y
      //  i = Math.min(Y.length()/2,60);
        //System.out.println("Y:"+Y.substring(0,i));
	//        System.out.println("Y:"+tmps.substring(0,i)+"..."+tmps.substring(tmps.length()-i,tmps.length()));  
        y = Y.toCharArray();
        l = Math.min(x.length,y.length);
        z = new char[l];
        int xi,yi,zi;
	for (i = 0;i<l-1;i++) {
            xi = (int) x[i+1] - (int) '0'; 
	    // xi = (int) x[i] - (int) '0'; 
            yi = (int) y[i] - (int) '0';
	    zi = xi + 2*yi;
	    z[i] = (char) (zi + (int) '0') ;
	}
        
	sourceseq = new String(z);
	//i = Math.min(sourceseq.length()/2,60);
	//System.out.println("Z:"+sourceseq.substring(0,i));  
    }




    
    public char nextSymbol(int step){ 
 
	if (pointer+step<=sourceseq.length()) { 
	    return sourceseq.charAt(pointer+=step);
	} else 
	    return '\0';
    }

    public void setPointer(int n) { 
	if ((n>=0) && (n<=sourceseq.length())) { 
	    pointer = n;
	}
    }

    public char nextSymbol(){ 
        int step =1;
	if (pointer+step<=sourceseq.length()) { 
	    return sourceseq.charAt(pointer+=step);
	} else 
	    return '\0';
    }

    public int nextSymbolInt(){ 
        int tmp;
	int step =1;
	if (pointer+step<sourceseq.length()) { 
            tmp = (int) sourceseq.charAt(pointer+=step) - (int) '0';
	    return tmp;
	} else 
	    return -1;
    }

    public int nextSymbolInt(int step){ 
        int tmp;
	if (pointer+step<sourceseq.length()) { 
            tmp = (int) sourceseq.charAt(pointer+=step) - (int) '0';
	    return tmp;
	} else 
	    return -1;
    }

    public Suffix getSuffix(int n){
	return new Suffix(sourceseq.substring(pointer-n+1,pointer+1));
    }

    public String getSuffixStr(int n){
	return sourceseq.substring(pointer-n+1,pointer+1);
    }
    
    public int length() { 
	return sourceseq.length();
    }

}







