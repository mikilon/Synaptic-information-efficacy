
import java.io.*;
import java.util.*;
import java.lang.String;

/**
 * SpikeTrainBinner should take an arraay of spike times and create a string 
 * of binary digits according to the bin size specified.
 *
 * @author shmulik
 */
public class SpikeTrainBinner {
    public float binsize;

    // The next numbers that appear in the file
    // null if the file is empty
    private Iterator readNumbers;

    // A cursor to the last line that has been read;
    // used in case of a format error, to inform about the
    // location of the error
    private int currentLineNumber;

    /**
     * Constructs an IntegerListReader to read a given file specified by its name.
     * @param spiketrain: and array with spike times
     * @throws IOException If there was a problem to read from the file
     * @throws NumberFormatException If the content of the file doesn't follow the
     * expected format - see class documentation.
     */
    public SpikeTrainBinner() { 

    }


    public void binsize(float b) { 
	binsize = b;
    }

    public String binIt(float[] spiketrain,float start, float duration) {
	float t;
	int i,loc;
	int binnedlength = (int)Math.ceil(duration/binsize);
	StringBuffer binnedspiketrain = new StringBuffer(binnedlength);
	for (i=0;i<binnedlength;i++) { 
	    binnedspiketrain.append('0');
	}

	for (i=0;i<spiketrain.length;i++) { 
	    t = spiketrain[i]-start;
	    
	    if (t<0) 
		continue;
	    if (t>=duration)
		continue;
	    loc = (int) Math.floor(t/binsize);  
	    //	    System.out.println(t + " " + loc+" " + binnedlength);
	    binnedspiketrain.setCharAt(loc, '1');
	}
	//	System.out.println(binnedspiketrain.toString());
	return binnedspiketrain.toString();
    }
}
