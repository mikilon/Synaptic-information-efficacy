import mpfun.*;
import java.io.*;
import java.lang.*;
/**
 * NoiseEntropyEstimator  allows to  estimate the entropy rate (in units of bits/symbol) 
 * of the noise when given many replicas of output spike train given the same stimulus. 
 * <br>
 * The class uses the CTW algorithm. For details of the CTW original algorithm see: <br>
 *  <a href="http://www.ics.ele.tue.nl/~fwillems/ResearchCTW.html">http://www.ics.ele.tue.nl/~fwillems/ResearchCTW.html</a>
 * <br>
 * For details of the adaptation of the algorithm to entropy estimation please look at either 
 * the file in this folder: <br>
 * Or look for it at:<br>
 *  <a href="http://www.dendrite.org/~mikilon/">http://www.dendrite.org/~mikilon/</a> <br>
 *  <a href="http://www.spike.ls.huji.ac.il/~mikilon/publications/">http://www.spike.ls.huji.ac.il/~mikilon/publications/</a>
 * <br>
 * @author Mickey London (m.london@ucl.co.uk, mikilon@lobster.ls.huji.ac.il) 
 */

public class CTWConditionalEntropyEstimator extends Object
{
    
    private SuffixNode root;
    public  CTWConditionalEntropyEstimator(SourceSequence sX,SourceSequence sXY,int D,int start,int steps) throws java.io.IOException
    {    
	int nextsym = -1;

	CTWConst.D = D;
	CTWConst.setRH();
	root = new SuffixNode();
	sX.setPointer(start);
	sXY.setPointer(start);
	for (int i = 0;i<steps;i++) {
	    if((nextsym = sX.nextSymbolInt()) != -1){ 
		sXY.nextSymbolInt(1);    
		root.update(sXY,nextsym);     
	    }
	}
    }
          
    public  void updateCTWConditionalEntropyEstimator(SourceSequence sX,SourceSequence sXY,int start,int steps) throws java.io.IOException
    {    
	int nextsym = -1;
	
	sX.setPointer(start);
	sXY.setPointer(start);
	for (int i = 0;i<steps;i++) {
	    if((nextsym = sX.nextSymbolInt()) != -1){
		sXY.nextSymbolInt(1);     
		root.update(sXY,nextsym); 
	    }
	}
    }

    public MPReal estimate() {
	root.updatePw();
	return  root.getData().Hhat();      
    } 
}






















