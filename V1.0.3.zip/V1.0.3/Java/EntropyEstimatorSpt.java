import mpfun.*;
import java.io.*;
import java.lang.*;
/**
 * EntropyEstimator  allows to  estimate the entropy rate (in units of bits/symbol) of a sequence of 
 * binary symbols. 
 * <br>
 * The class uses the CTW algorithm. For details of the CTW original algorithm see: <br>
 *  <a href="http://www.ics.ele.tue.nl/~fwillems/ResearchCTW.html">http://www.ics.ele.tue.nl/~fwillems/ResearchCTW.html</a>
 * <br>
 * For details of the adaptation of the algorithm to entropy estimation please look at either 
 * the file in this folder: <br>
 * Or look for it at:<br>
 *  <a href="http://www.dendrite.org/~mikilon/">http://www.dendrite.org/~mikilon/</a> <br>
 *  <a href="http://www.spike.ls.huji.ac.il/~mikilon/publications/">http://www.spike.ls.huji.ac.il/~mikilon/publications/</a>
 * <br>
 * @author Mickey London (m.london@ucl.co.uk, mikilon@lobster.ls.huji.ac.il) 
 */


public final class EntropyEstimatorSpt
{
  public static void main(String args[]) throws java.io.IOException
  {    
    
    int nextsym = -1;
    MPReal estimator;
    
    CTWConst.D = Integer.parseInt(args[0]);

    SuffixNode root = new SuffixNode();
    float start = Float.parseFloat(args[2]);
    float duration = Float.parseFloat(args[3]);
    float binsize = Float.parseFloat(args[4]);
    SourceSequence source = new SourceSequence(args[1],start,duration,binsize);
    
    while((nextsym = source.nextSymbolInt()) != -1){ 
	root.update(source,nextsym);     
    }

    root.updatePw();
    estimator = root.getData().Hhat(); 
    System.out.println("Est:"+estimator.doubleValue());
    System.exit(0);
  }
}






















