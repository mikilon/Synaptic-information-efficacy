import mpfun.*;

import java.util.*;
import java.text.*;

public class NodeData extends Object{


    int[] counts = new int[CTWConst.alphabet];
    MPReal Pe;
    MPReal Pw;
    MPReal PeDelta;
    DecimalFormat sciFormatter;
    static String scipat = "#.##E0";
    MPReal ONE = new MPReal(1.0);
    MPReal HALF = new MPReal(0.5);
    MPReal ZERO = new MPReal (0);
    

    public NodeData(){
        for (int i=0;i<CTWConst.alphabet;i++) { 
	    counts[i] = 0;
	}

        Pe = new MPReal(1.0);
        Pw = new MPReal(1.0); 
        sciFormatter = new DecimalFormat(scipat);

    }

    private void updateKT(int which){
        MPReal PeD;
	PeD = PeDelta(counts,which);
	Pe = PeD.multiply(Pe);
    }

    private void incCounts(int which){      
	counts[which]++;
    }

    private MPReal Pml() { 
	MPReal ml,theta,a,b,sum;
        b   = new MPReal(counts[1]);
        sum = new MPReal(counts[0]+counts[1]);
	
        theta = b.divide(sum);
        ml = ((ONE.subtract(theta).pow(counts[0])).multiply(theta.pow(counts[1])));
	return ml;
    }
	    
    public void copyCounts(SuffixNode t){      
        Pe = t.getData().getPe();
        Pw = t.getData().getPw();
        for (int i=0;i<CTWConst.alphabet;i++) { 
	    counts[i] = t.getData().counts[i];
	}
    }

    public void updatePw(SuffixNode t) { 
	if (CTWConst.method ==2 ) { 
 	     Pe = Pml();
	}
	if (t.isLeaf()) { 
           Pw = Pe;
        } else { 
           Pw = CompPw(t);
        }
    }

    public void updateCounts(SuffixNode t,int which){ 
        if (CTWConst.method ==1 ) { 
	    updateKT(which);
	    incCounts(which); 
	    // updatePw(t);        // need to update Pw on each time step
            // only if wants the output along the way
            // make a flag for this later
	} else if (CTWConst.method ==2 ) { // maimum likelyhood 
	    incCounts(which); 
	    //	    Pe = Pml(counts,which);
	}
    }           

    private MPReal CompPw(SuffixNode t){
    	MPReal numer;        
        MPReal[] sPw = new MPReal[CTWConst.inalphabet];
        MPReal sonsmulPw;


        for (int i=0;i<CTWConst.inalphabet;i++) {  
	    sPw[i] = t.getSon(i).getData().getPw();
        }
        sonsmulPw = mulPw(sPw);

        numer = Pe.add(sonsmulPw);
  
        numer = HALF.multiply(numer);
        
        return numer;
    }
 
    private MPReal mulPw(MPReal[] sPw) { 
	MPReal mul = new MPReal(1.0); 
        for (int i=0;i<sPw.length;i++) {  
	    mul = mul.multiply(sPw[i]);
        }
	//	System.out.println("mul:"+mul.doubleValue()); 
        return mul;
    }

    private MPReal PeDelta(int[] counts,int which){
    	MPReal numer,denom;
        numer = new MPReal(counts[which]);
        numer = HALF.add(numer);
        denom = new MPReal(counts[0]+ counts[1]+1); 
/*	System.out.println("Numer/Denom: "+numer.doubleValue()+"/"+denom.doubleValue()); */
        return numer.divide(denom);
    }

    public MPReal getPw(){
        return Pw;
    }

    public MPReal getPe(){
        return Pe;
    }
    
    public MPReal log2Pw(){
    	MPReal lo2,logpw;        
        lo2 = new MPReal(2);
        logpw = this.Pw.log();
        lo2 = lo2.log();  
        return logpw.divide(lo2);
    }

    public MPReal Hhat(){
    	MPReal n,log2pw;       
        n = new MPReal((counts[0]+ counts[1])*(-1)); 
        log2pw = log2Pw();
        return log2pw.divide(n);
    }


    public int getCounts(int which){
        return counts[which];
    }

    public String toString(){
          String spe,spw;

        spe = sciFormatter.format(Pe.doubleValue());
        spw = sciFormatter.format(Pw.doubleValue());
       
        return "("+counts[0]+","+counts[1]+","+spe+","+spw+")";
//        return "("+counts[0]+","+counts[1]+","+Pe.doubleValue()+","+Pw.doubleValue()+")";
    } 

    
/*    public String toString(){
        return "a:"+counts[0]+"\tb:"+counts[1] + "\n" + "Pe:" + Pe.toString() + "\tPw:"+Pw.toString() + "\n";
    } */
    
}


    


