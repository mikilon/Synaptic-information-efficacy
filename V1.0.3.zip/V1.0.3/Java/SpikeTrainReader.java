import java.io.*;
import java.util.*;

/**
 * IntegerListReader allows to read a textual file that contains a list of integersfloting points.
 * The file is expected to have a specific format: each line consist of one number
 * Whitespace characters within the line are ignored,
 * empty lines are ignored as well.
 *
 * @author shmulik
 */
public class SpikeTrainReader {

    // The underlying reader used to read the file
    private BufferedReader reader;

    // The next numbers that appear in the file
    // null if the file is empty
    private Iterator readNumbers;

    // A cursor to the last line that has been read;
    // used in case of a format error, to inform about the
    // location of the error
    private int currentLineNumber;

    /**
     * Constructs an IntegerListReader to read a given file specified by its name.
     * @param filename The name of the file to read
     * @throws IOException If there was a problem to read from the file
     * @throws NumberFormatException If the content of the file doesn't follow the
     * expected format - see class documentation.
     */
    public SpikeTrainReader(String filename)
        throws IOException, NumberFormatException {

        this(new File(filename));
    }

    /**
     * Constructs an IntegerListReader to read a given file specified by its name.
     * @param file The file to read
     * @throws IOException If there was a problem to read from the file
     * @throws NumberFormatException If the content of the file doesn't follow the
     * expected format - see class documentation.
     */
    public SpikeTrainReader(File file)
        throws IOException, NumberFormatException {

        this(new FileReader(file));
    }

    /**
     * Constructs an IntegerListReader to read a given file specified by its name.
     * @param reader A reader of the text that we want to parse
     * @throws IOException If there was a problem to read from the file
     * @throws NumberFormatException If the content of the file doesn't follow the
     * expected format - see class documentation.
     */
    public SpikeTrainReader(Reader reader)
        throws IOException, NumberFormatException {

        this.reader = new BufferedReader(reader);
        readAhead();
    }

    /**
     * Returns <TT>true</TT> iff there are more numbers to read from the file
     * @return <TT>true</TT> iff there are more numbers to read from the file
     */
    public boolean hasMoreElements() {
        return readNumbers != null && readNumbers.hasNext();
    }


    public float[] readSpikeTrain() {
	float[] sptf;
	Vector spt = new Vector();
        try {
            while (this.hasMoreElements()) {
		spt.addElement(new Float(this.readNextFloat()));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
	
	sptf = new float[spt.size()];
	sptf = vec2FloatArray(spt);
	
	return sptf;
    }

    /**
     * Reads the next integer from the file.
     * @return The next integer that appear in the file.
     * @throws EOFException If there are no more numbers to be read from the file.
     * @throws IOException If there was a problem to read from the file
     * @throws NumberFormatException If the content of the file doesn't follow the
     * expected format - see class documentation.
     */
    public float readNextFloat()
        throws NumberFormatException, IOException {

        if (!hasMoreElements()) {
            throw new EOFException(
                "There are no more numbers in the stream");
        }
        Float wrapper = (Float)readNumbers.next();
        if (!readNumbers.hasNext()) {
            readAhead();
        }
        return wrapper.floatValue();
    }

    // Continues to read from the file until the next line which is not empty
    // (that contains numbers) and set the variable 'readNumbers' to be an
    // Iterator to the list of numbers in that line.
    // If there are no more non-empty lines in the file, 'readNumbers' will be
    // set to null
    private void readAhead() throws NumberFormatException, IOException {
        do {
            String line = reader.readLine();

            currentLineNumber++;
            if (line == null) {
                readNumbers = null;
                return;
            }
	    //	

	    readNumbers = parseLine(line);

        } while (!readNumbers.hasNext());
    }

    // Parses the content of a given line, returns an Iterator to the list
    // of integers in that line or throws NumberFormatException if that line
    // is not a list of comma delimited integers
    private Iterator parseLine(String line) throws NumberFormatException {
	ArrayList numbers = new ArrayList();
	if ((line.indexOf('#') >= 0 ) || (line.indexOf('%') >= 0) ) { 
	    //System.out.println("Skipping comment line: " + line);	    
	} else { 
	    StringTokenizer tokenizer = new StringTokenizer(line, " ");
	    //	    StringTokenizer tokenizer = new StringTokenizer(line, ",");
	    while (tokenizer.hasMoreTokens()) {
		String token = tokenizer.nextToken().trim();
		try {
		    Float value = Float.valueOf(token);
		    numbers.add(value);
		} catch (NumberFormatException nfe) {
		    throw new NumberFormatException(
						    "Format exception at line "+currentLineNumber+": " +
						    "expected an integer, found '"+token+"'");
		}
	    }
	}
        return numbers.iterator();
    }



    public  float[] vec2FloatArray(Vector v){
	float[] a = new float[v.size()];
	int count=0;
	Enumeration e = v.elements();
	while( e.hasMoreElements() ){
	    Float wrapper = (Float) e.nextElement();
	    a[ count ] = wrapper.floatValue();
	    count += 1;
	}
	return a;
    }
    
}
