import java.io.*;
import java.util.*;

/**
 * FileListReader allows to read a textual file that contains a list of strings.
 * The file is expected to have a specific format: each line consist of one string
 * Whitespace characters within the line are ignored,
 * empty lines are ignored as well.
 *
 * @author shmulik, modified by Mickey
 */
public class FileListReader {

    // The underlying reader used to read the file
    private BufferedReader reader;

    // The next numbers that appear in the file
    // null if the file is empty
    private Iterator readStrings;

    // A cursor to the last line that has been read;
    // used in case of a format error, to inform about the
    // location of the error
    private int currentLineNumber;

    /**
     * Constructs an IntegerListReader to read a given file specified by its name.
     * @param filename The name of the file to read
     * @throws IOException If there was a problem to read from the file
     * @throws NumberFormatException If the content of the file doesn't follow the
     * expected format - see class documentation.
     */
    public FileListReader(String filename) throws IOException{ 

        this(new File(filename));
    }

    /**
     * Constructs an IntegerListReader to read a given file specified by its name.
     * @param file The file to read
     * @throws IOException If there was a problem to read from the file
     * @throws NumberFormatException If the content of the file doesn't follow the
     * expected format - see class documentation.
     */
    public FileListReader(File file) throws IOException { 

        this(new FileReader(file));
    }

    /**
     * Constructs an IntegerListReader to read a given file specified by its name.
     * @param reader A reader of the text that we want to parse
     * @throws IOException If there was a problem to read from the file
     * @throws NumberFormatException If the content of the file doesn't follow the
     * expected format - see class documentation.
     */
    public FileListReader(Reader reader){ 

        this.reader = new BufferedReader(reader);
	
    }
    /**
     * Reads the next integer from the file.
     * @return The next integer that appear in the file.
     * @throws EOFException If there are no more numbers to be read from the file.
     * @throws IOException If there was a problem to read from the file
     * @throws NumberFormatException If the content of the file doesn't follow the
     * expected format - see class documentation.
     */
    public String readNextString() throws IOException {
	while (true) { 
	    String line = reader.readLine();
	    currentLineNumber++;
	    if (line == null) {
		return null;
	    }
	    if ((line.indexOf('#') >0 ) ||  (line.indexOf('%') > 0) ){
		continue;
	    }	
	    return line;
	}
	
    }
}