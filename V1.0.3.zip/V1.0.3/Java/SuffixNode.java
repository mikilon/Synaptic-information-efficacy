import java.awt.*;

public class SuffixNode{
    protected NodeData data;
    protected SuffixNode[] Sons;
    protected SuffixNode parent;
    public Point location;
    private   boolean isleaf;
    public    int level;
    public    int label;

    public SuffixNode(){
        data = new NodeData();
	initSons();
        isleaf  = true;
        level = 1;
        location = null;
        parent = null;
        label  = -1;
    }

    public SuffixNode(SuffixNode parent, int setlabel){
        data    = new NodeData();
	initSons();
        isleaf  = true;
        label   = setlabel;
        inherit(parent);               
        location = null;
    }

    private void initSons() { 
        Sons = new SuffixNode[CTWConst.inalphabet];  
	for (int i=0;i<Sons.length;i++) { 
	    Sons[i] = null;
	}
    }


    public void getInfo() { 
       	System.out.println("Leaf:"+isleaf+"\tLabel:"+label+"\tLevel:"+level+"\n\t"+data.toString());
    }


    private void inherit(SuffixNode parent) {
	level = parent.getLevel()+1;
        this.parent = parent;
    }
    
    public void copyCounts(SuffixNode t) { 
	data.copyCounts(t);
    }

    public SuffixNode getParent() { 
	return parent;
    }

    public int getLevel() { 
	return level;
    }

    public int getLabel() { 
	return label;
    }

    public void setSon(SuffixNode n, int s){
        Sons[s] = n;
    }
 
    public SuffixNode getSon(int s) { 
        return Sons[s]; 	
    }


    public SuffixNode getSonByLabel(char s) { 
        int l =  (int) s -  (int) '0';
	//System.out.println("Label:"+l);
	//System.out.println(l);
        return Sons[l]; 	
    }
    
    public void setData(NodeData d){
        data = d;
    }
    
    public NodeData getData(){
        return data;
    }

    public boolean isRoot(){
	return (parent == null);	
    }

    public void createSons(){
	for (int i=0;i<Sons.length;i++) {      // No epsilon son here
	    Sons[i] = new SuffixNode(this,i);
	}
        isleaf = false;    // after creating the sons this node is not a leaf anymore
    }

    public boolean isLeaf() { 
	return isleaf;
    }

    public void update(SourceSequence s, int nextsym){
        SuffixNode t;
        int D = CTWConst.D;
	Suffix suff = s.getSuffix(this.level+1);
        //System.out.println("Suffix:"+suff.toString());
	if (isLeaf()) { 
	    if (this.level < D) { 
		createSons();
		//t = getSonByLabel(suff.popLeft());   // redundent !!!!!
		//t = getSon(CTWConst.inalphabet-1);
		t = getSon(0);
		t.copyCounts(this);
		t = getSonByLabel(suff.popLeft());
	        t.data.updateCounts(t, nextsym);              
	    }	   		       
	} else {
	    t = getSonByLabel(suff.popLeft());
	    t.update(s,nextsym);                      	      		
    	}
        this.data.updateCounts(this, nextsym);
	//	this.getInfo();

    }



    public void updatePw(){

        int D = CTWConst.D;
	if (isLeaf()) { 
	    data.updatePw(this);              
	} else { 
	    for (int i =0;i<Sons.length;i++) { 
		getSon(i).updatePw();
	    }
	    data.updatePw(this);              
	}
    }




/***
 *      Traversals
 ***/
        public void pretrav(SuffixNode p){
          if(p == null)
            return;
            System.out.print(p.level + "\t" + p.getData()+"\n");
	    for (int i =0;i<Sons.length;i++) { 
		pretrav(p.getSon(i));
	    }
        }
}
    









