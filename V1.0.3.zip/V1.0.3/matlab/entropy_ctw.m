function e = entropy_ctw_vector(spt,st,en,b,D)
% e = entropy_ctw_vectorspt(n,st,en,b,D)
% Compute the entropy of a spike trai.
% spt a vector containig spike times
% st, en - start and end times to consider for estimation
% D - maximal depth of CTW tree
% b - bin size
 

CTWConst.D = D;
dur = en-st;
if (size(spt,2) == 1)  % if sent a column vector make it to a row vector 
    spt = spt';
end

for i=(1:size(spt,1))  % loop through the rows
    s = spt(i,:); % spike train to process
    sourceX = SourceSequence(spt,st,dur,b);

    if (i==1) 
        estimator =  CTWEntropyEstimator(sourceX,D,D+1,sourceX.length()-D-1);   
    else
        estimator.updateCTWEntropyEstimator(sourceX,D+1,sourceX.length()-D-1);
    end
end
e = estimator.estimate().floatValue()/b*1000;

