function [mi,h,ch,chshuffle] = mutual_information_ctw(sptin,sptout,st,en,b,D,shiftinput)
%  [mi,h,ch,chshuffle] = mutual_information_ctw(sptin,sptout,st,en,b,D,shiftinput)
% Compute the mutual information rate between input and output spike trains.
% sptin, sptout are vecors containing times of spikes, or cell arrays
%    of vectors containg spike trains. In the latter case the algorithm continues to update the
%    CTW tree as if all the spike trains were concatenated.
% st, en - start and end time between which times of spikes are relevant. en can be longer than last spike time
% but the algorith runs only untile the last spike (not included). In this
% way we do not add artificial or erroneous zeros in the end.
% b - bin size
% D - length of history (in bins). This is also the maximum depth of the CTW tree
% shift input - shift the time of the input by a ceratin amount (default is 0) in case
% of a known minium lag between the input and output spike trains.

% Mickey London - mikilon@gmail.com 27.6.07



if (nargin < 7 )
    shiftinput = 0;
end


CTWConst.D = D;
dur = en-st;
multi = 0;  % more than 1 pair of input. out out spike tains

% prepare the input
if (iscell(sptout) && (iscell(sptin)) )
    multi = 1;
    if (size(sptin) ~= size(sptout))
        error('Mickey - error in sie_ctw: input and output spiketrains are cell array but not of the same size');
    end
    spin = sort(sptin{1}); % spike train to process
    spout = sort(sptout{1}); %

else
    if (size(sptout,2) == 1)  % if sent a column vector make it to a row vector
        sptout = sptout';
    end

    if (size(sptin,2) == 1)  % if sent a column vector make it to a row vector
        sptin = sptin';
    end
    spin = sort(sptin); % spike train to process
    spout = sort(sptout); %
end
if (isempty (spin))
    error('empty input spike train');
end
if (isempty (spout))
    error('empty output spike train');
end


thisend = min(en,max(sptout)-1); % we go up to just before the last spike on the output
spin((spin>thisend)) = [];       % kill everything in the input spike train that is longet than 
                                 % than the last spike of the outout
sourceX = SourceSequence(spout,st,dur,b); % Generate the 0,1 sequences that the algorith use, via
sourceXY = SourceSequence(spin,spout,st,dur,b,shiftinput);  % a class in java class SourceSequence

h_estimator = CTWEntropyEstimator(sourceX,D,D+1,sourceX.length()-D-1); %this is the java object that estimates the entropy 
ch_estimator =  CTWConditionalEntropyEstimator(sourceX,sourceXY,D,D+1,sourceX.length()-D-1);

if (multi)  % If there is more than one pair of input and output than we continue to update the tree
    for(i=2:lenght(sptin))
        spin = sort(sptin{i}); % spike train to process
        if (isempty (spin))
            error('empty input spike train');
        end
        spout = sort(sptout{i}); %
        if (isempty (spout))
            error('empty output spike train');
        end
        thisend = min(en,max(spout)-1);
        spin((spin>thisend)) = [];
        h_estimator = updateCTWEntropyEstimator(sourceX,D+1,sourceX.length()-D-1);
        ch_estimator.updateCTWConditionalEntropyEstimator(sourceX,sourceXY,D+1,sourceX.length()-D-1);
    end
end


h = h_estimator.estimate().floatValue()/b*1000;  % now we read the final value and convert to bits/s
ch = ch_estimator.estimate().floatValue()/b*1000; 
clear h_estimator ch_estimator sourceX sourceXY; % clear the memory (Tree tend to take lots of maemory)


%Now doing it again for the shuffled input

if (multi) % if there are several pairs of in/out we need to reset to the first pair 
    spin = sort(sptin{1}); % spike train to process
    spout = sort(sptout{1}); %
    thisend = min(en,max(spout)-1);
    spin((spin>thisend)) = [];   
end

% Now computing the suffled version of the input
if (numel(spin)>1) 
    isi = diff(spin);
    [jnk,r]  = sort(rand(size(isi)));
    spinshuffle = cumsum(isi(r));
else
    spinshuffle = rand(1,1)*dur;
end
sourceX = SourceSequence(spout,st,dur,b);
sourceXYshuffle = SourceSequence(spinshuffle,spout,st,dur,b,shiftinput);
chshuffle_estimator =  CTWConditionalEntropyEstimator(sourceX,sourceXYshuffle,D,D+1,sourceX.length()-D-1);

if (multi)
    for i=(2:length(sptin))      % loop through the rest of the pair
        spin = sort(sptin{i}); % spike train to process
        spout = sort(sptout{i}); %
        thisend = min(en,max(sptout)-1); % we go up to just before the last spike on the output
        spin((spin>thisend)) = [];
        isi = diff(spin);
        [jnk,r]  = sort(rand(size(isi)));
        spinshuffle = cumsum(isi(r));
        sourceX = SourceSequence(spout,st,dur,b);
        sourceXYshuffle = SourceSequence(spinshuffle,spout,st,dur,b,shiftinput);
        chshuffle_estimator.updateCTWConditionalEntropyEstimator(sourceX,sourceXYshuffle,D+1,sourceX.length()-D-1);
    end
end


chshuffle = chshuffle_estimator.estimate().floatValue()/b*1000;
clear chshuffle_estimator sourceXYshuffle sourceX
mi = chshuffle - ch;
